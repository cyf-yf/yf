const fs = require('fs');
const path = require('path');

const iconsDir = path.join(__dirname, '../src/static/icons');

const icons = {
  home: createIcon('#999999'),
  'home-active': createIcon('#4A90D9'),
  dormitory: createIcon('#999999'),
  'dormitory-active': createIcon('#4A90D9'),
  maintenance: createIcon('#999999'),
  'maintenance-active': createIcon('#4A90D9'),
  notice: createIcon('#999999'),
  'notice-active': createIcon('#4A90D9'),
  profile: createIcon('#999999'),
  'profile-active': createIcon('#4A90D9')
};

function createIcon(color) {
  const size = 48;
  const center = size / 2;
  const radius = 16;
  
  const png = [];
  
  png.push(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A);
  
  const ihdr = [
    (size >> 24) & 0xFF, (size >> 16) & 0xFF, (size >> 8) & 0xFF, size & 0xFF,
    (size >> 24) & 0xFF, (size >> 16) & 0xFF, (size >> 8) & 0xFF, size & 0xFF,
    8, 6, 0, 0, 0
  ];
  const ihdrCrc = crc32([0x49, 0x48, 0x44, 0x52, ...ihdr]);
  png.push(0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52, ...ihdr, ...int32ToBytes(ihdrCrc));
  
  const rawData = [];
  for (let y = 0; y < size; y++) {
    rawData.push(0);
    for (let x = 0; x < size; x++) {
      const dx = x - center;
      const dy = y - center;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      if (dist <= radius) {
        const r = parseInt(color.slice(1, 3), 16);
        const g = parseInt(color.slice(3, 5), 16);
        const b = parseInt(color.slice(5, 7), 16);
        rawData.push(r, g, b, 255);
      } else {
        rawData.push(0, 0, 0, 0);
      }
    }
  }
  
  const { deflateSync } = require('zlib');
  const compressed = deflateSync(Buffer.from(rawData));
  
  const idatCrc = crc32([0x49, 0x44, 0x41, 0x54, ...compressed]);
  png.push(...int32ToBytes(compressed.length), 0x49, 0x44, 0x41, 0x54);
  png.push(...compressed);
  png.push(...int32ToBytes(idatCrc));
  
  const iendCrc = crc32([0x49, 0x45, 0x4E, 0x44]);
  png.push(0, 0, 0, 0, 0x49, 0x45, 0x4E, 0x44, ...int32ToBytes(iendCrc));
  
  return Buffer.from(png);
}

function crc32(data) {
  let crc = 0xFFFFFFFF;
  const table = [];
  
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  
  for (const byte of data) {
    crc = table[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  }
  
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function int32ToBytes(val) {
  return [
    (val >> 24) & 0xFF,
    (val >> 16) & 0xFF,
    (val >> 8) & 0xFF,
    val & 0xFF
  ];
}

if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

for (const [name, buffer] of Object.entries(icons)) {
  fs.writeFileSync(path.join(iconsDir, `${name}.png`), buffer);
  console.log(`Created ${name}.png`);
}

console.log('All icons generated!');
