<template>
  <view class="stats-container">
    <view class="stats-header">
      <text class="stats-title">数据统计</text>
    </view>

    <view class="stats-summary">
      <view class="summary-card">
        <text class="summary-value">{{ stats.totalStudents }}</text>
        <text class="summary-label">总学生数</text>
      </view>
      <view class="summary-card">
        <text class="summary-value">{{ stats.totalDorms }}</text>
        <text class="summary-label">宿舍总数</text>
      </view>
      <view class="summary-card">
        <text class="summary-value">{{ stats.occupiedRate }}%</text>
        <text class="summary-label">入住率</text>
      </view>
      <view class="summary-card">
        <text class="summary-value">{{ stats.pendingRepairs }}</text>
        <text class="summary-label">待处理报修</text>
      </view>
    </view>

    <view class="stats-section">
      <view class="section-title">各楼栋入住情况</view>
      <view class="building-list">
        <view class="building-item" v-for="building in buildingStats" :key="building.name">
          <view class="building-info">
            <text class="building-name">{{ building.name }}</text>
            <text class="building-count">{{ building.occupied }}/{{ building.total }}</text>
          </view>
          <view class="building-progress">
            <view class="progress-bar" :style="{ width: building.rate + '%' }"></view>
          </view>
          <text class="building-rate">{{ building.rate }}%</text>
        </view>
      </view>
    </view>

    <view class="stats-section">
      <view class="section-title">本周报修统计</view>
      <view class="repair-chart">
        <view class="chart-bars">
          <view class="bar-item" v-for="(count, day) in repairWeekly" :key="day">
            <view class="bar-container">
              <view class="bar" :style="{ height: (count / maxRepairCount * 100) + '%' }"></view>
            </view>
            <text class="bar-label">{{ day }}</text>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

const stats = ref({
  totalStudents: 1256,
  totalDorms: 312,
  occupiedRate: 94,
  pendingRepairs: 8
})

const buildingStats = ref([
  { name: '1号楼', occupied: 180, total: 200, rate: 90 },
  { name: '2号楼', occupied: 192, total: 200, rate: 96 },
  { name: '3号楼', occupied: 175, total: 180, rate: 97 },
  { name: '4号楼', occupied: 168, total: 180, rate: 93 },
  { name: '5号楼', occupied: 185, total: 200, rate: 92 }
])

const repairWeekly = ref({
  '周一': 5,
  '周二': 8,
  '周三': 3,
  '周四': 6,
  '周五': 4,
  '周六': 2,
  '周日': 1
})

const maxRepairCount = computed(() => {
  return Math.max(...Object.values(repairWeekly.value))
})
</script>

<style lang="scss" scoped>
.stats-container {
  min-height: 100vh;
  background: #f5f5f5;
}

.stats-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.stats-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.stats-summary {
  display: flex;
  padding: 20rpx;
  gap: 16rpx;
}

.summary-card {
  flex: 1;
  background: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  text-align: center;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.summary-value {
  display: block;
  font-size: 40rpx;
  font-weight: bold;
  color: #4A90D9;
}

.summary-label {
  display: block;
  font-size: 22rpx;
  color: #999;
  margin-top: 8rpx;
}

.stats-section {
  margin: 20rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.section-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 20rpx;
}

.building-item {
  display: flex;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.building-info {
  width: 160rpx;
}

.building-name {
  display: block;
  font-size: 28rpx;
  color: #333;
}

.building-count {
  display: block;
  font-size: 22rpx;
  color: #999;
}

.building-progress {
  flex: 1;
  height: 16rpx;
  background: #f0f0f0;
  border-radius: 8rpx;
  margin: 0 16rpx;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, #4A90D9, #6BA3E0);
  border-radius: 8rpx;
  transition: width 0.3s;
}

.building-rate {
  width: 80rpx;
  font-size: 26rpx;
  color: #4A90D9;
  text-align: right;
}

.chart-bars {
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  height: 200rpx;
  padding-top: 20rpx;
}

.bar-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.bar-container {
  width: 40rpx;
  height: 160rpx;
  background: #f5f5f5;
  border-radius: 8rpx;
  display: flex;
  align-items: flex-end;
  overflow: hidden;
}

.bar {
  width: 100%;
  background: linear-gradient(180deg, #4A90D9, #6BA3E0);
  border-radius: 8rpx;
  transition: height 0.3s;
}

.bar-label {
  font-size: 22rpx;
  color: #999;
  margin-top: 12rpx;
}
</style>
