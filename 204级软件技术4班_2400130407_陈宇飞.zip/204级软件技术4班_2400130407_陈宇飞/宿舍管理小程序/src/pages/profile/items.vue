<template>
  <view class="items-container">
    <view class="items-header">
      <text class="items-title">物品登记</text>
    </view>

    <view class="tabs">
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'in' }"
        @click="activeTab = 'in'"
      >入库</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'out' }"
        @click="activeTab = 'out'"
      >出库</view>
    </view>

    <view class="search-bar">
      <input class="search-input" placeholder="搜索物品名称" v-model="searchText" />
    </view>

    <view class="items-list">
      <view class="item-card" v-for="item in filteredItems" :key="item.id">
        <view class="item-header">
          <view class="item-icon">{{ getCategoryIcon(item.category) }}</view>
          <view class="item-info">
            <text class="item-name">{{ item.name }}</text>
            <text class="item-category">{{ getCategoryText(item.category) }}</text>
          </view>
          <view class="item-status" :class="item.status">
            {{ item.status === 'in' ? '在库' : '已出库' }}
          </view>
        </view>
        <view class="item-body">
          <view class="body-row">
            <text class="row-label">数量</text>
            <text class="row-value">{{ item.quantity }} {{ item.unit }}</text>
          </view>
          <view class="body-row">
            <text class="row-label">登记人</text>
            <text class="row-value">{{ item.registerBy }}</text>
          </view>
          <view class="body-row">
            <text class="row-label">登记时间</text>
            <text class="row-value">{{ item.registerTime }}</text>
          </view>
          <view class="body-row">
            <text class="row-label">备注</text>
            <text class="row-value">{{ item.remark }}</text>
          </view>
        </view>
        <view class="item-footer">
          <view class="footer-btn" v-if="item.status === 'in'" @click="outItem(item)">出库</view>
          <view class="footer-btn" v-else @click="inItem(item)">入库</view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredItems.length === 0">
      <text class="empty-icon">📦</text>
      <text class="empty-text">暂无{{ activeTab === 'in' ? '入库' : '出库' }}记录</text>
    </view>

    <view class="add-btn" @click="addItem">
      <text>+ 新增物品登记</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

interface Item {
  id: string
  name: string
  category: 'tool' | 'clean' | 'repair' | 'other'
  quantity: number
  unit: string
  status: 'in' | 'out'
  registerBy: string
  registerTime: string
  remark: string
}

const activeTab = ref<'in' | 'out'>('in')
const searchText = ref('')

const items = ref<Item[]>([
  { id: '1', name: '扫帚', category: 'clean', quantity: 20, unit: '把', status: 'in', registerBy: '管理员', registerTime: '2024-01-20 10:00', remark: '清洁用品' },
  { id: '2', name: '拖把', category: 'clean', quantity: 15, unit: '把', status: 'in', registerBy: '管理员', registerTime: '2024-01-20 10:05', remark: '清洁用品' },
  { id: '3', name: '螺丝刀', category: 'tool', quantity: 10, unit: '把', status: 'out', registerBy: '管理员', registerTime: '2024-01-22 14:30', remark: '维修工具' },
  { id: '4', name: '扳手', category: 'tool', quantity: 8, unit: '把', status: 'in', registerBy: '管理员', registerTime: '2024-01-20 10:10', remark: '维修工具' },
  { id: '5', name: '灯泡', category: 'repair', quantity: 50, unit: '个', status: 'in', registerBy: '管理员', registerTime: '2024-01-21 09:00', remark: '照明维修' },
  { id: '6', name: '门锁', category: 'repair', quantity: 10, unit: '套', status: 'out', registerBy: '管理员', registerTime: '2024-01-23 11:00', remark: '门锁更换' },
  { id: '7', name: '垃圾桶', category: 'other', quantity: 30, unit: '个', status: 'in', registerBy: '管理员', registerTime: '2024-01-19 15:00', remark: '宿舍用品' },
  { id: '8', name: '垃圾桶袋', category: 'other', quantity: 100, unit: '卷', status: 'in', registerBy: '管理员', registerTime: '2024-01-19 15:10', remark: '宿舍用品' }
])

const filteredItems = computed(() => {
  let result = items.value.filter(item => item.status === activeTab.value)
  if (searchText.value) {
    result = result.filter(item => item.name.includes(searchText.value))
  }
  return result
})

function getCategoryText(category: string) {
  const texts: Record<string, string> = {
    tool: '工具',
    clean: '清洁',
    repair: '维修',
    other: '其他'
  }
  return texts[category] || category
}

function getCategoryIcon(category: string) {
  const icons: Record<string, string> = {
    tool: '🔧',
    clean: '🧹',
    repair: '🔩',
    other: '📦'
  }
  return icons[category] || '📋'
}

function outItem(item: Item) {
  uni.showModal({
    title: '物品出库',
    content: `确定将「${item.name}」出库吗？`,
    success: (res) => {
      if (res.confirm) {
        const index = items.value.findIndex(i => i.id === item.id)
        if (index !== -1) {
          items.value[index].status = 'out'
        }
        uni.showToast({ title: '已出库', icon: 'success' })
      }
    }
  })
}

function inItem(item: Item) {
  uni.showModal({
    title: '物品入库',
    content: `确定将「${item.name}」入库吗？`,
    success: (res) => {
      if (res.confirm) {
        const index = items.value.findIndex(i => i.id === item.id)
        if (index !== -1) {
          items.value[index].status = 'in'
        }
        uni.showToast({ title: '已入库', icon: 'success' })
      }
    }
  })
}

function addItem() {
  uni.showActionSheet({
    itemList: ['工具', '清洁用品', '维修配件', '其他'],
    success: (res) => {
      const categories = ['tool', 'clean', 'repair', 'other']
      const categoryLabels = ['工具', '清洁用品', '维修配件', '其他']
      
      uni.showModal({
        title: '新增物品登记',
        editable: true,
        placeholderText: '格式：物品名称 数量 单位（如：钳子 5 把）',
        success: (modalRes) => {
          if (modalRes.confirm) {
            const content = modalRes.content || ''
            const parts = content.split(' ')
            const name = parts[0] || '物品'
            const quantity = parseInt(parts[1]) || 1
            const unit = parts[2] || '个'
            
            const now = new Date()
            const time = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
            
            items.value.unshift({
              id: Date.now().toString(),
              name: name,
              category: categories[res.tapIndex] as 'tool' | 'clean' | 'repair' | 'other',
              quantity: quantity,
              unit: unit,
              status: 'in',
              registerBy: '管理员',
              registerTime: time,
              remark: categoryLabels[res.tapIndex]
            })
            
            uni.showToast({ title: '登记成功', icon: 'success' })
          }
        }
      })
    }
  })
}
</script>

<style lang="scss" scoped>
.items-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.items-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.items-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.tabs {
  display: flex;
  background: #fff;
  padding: 0 20rpx;
}

.tab-item {
  flex: 1;
  padding: 24rpx;
  text-align: center;
  font-size: 28rpx;
  color: #999;
  position: relative;
  
  &.active {
    color: #4A90D9;
    font-weight: bold;
    
    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 60rpx;
      height: 6rpx;
      background: #4A90D9;
      border-radius: 3rpx;
    }
  }
}

.search-bar {
  padding: 20rpx;
}

.search-input {
  width: 100%;
  padding: 20rpx;
  background: #fff;
  border-radius: 40rpx;
  font-size: 28rpx;
  box-sizing: border-box;
}

.items-list {
  padding: 0 20rpx;
}

.item-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.item-header {
  display: flex;
  align-items: center;
  margin-bottom: 16rpx;
}

.item-icon {
  font-size: 48rpx;
  margin-right: 16rpx;
}

.item-info {
  flex: 1;
}

.item-name {
  display: block;
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.item-category {
  display: block;
  font-size: 24rpx;
  color: #999;
  margin-top: 4rpx;
}

.item-status {
  font-size: 24rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
  
  &.in {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.out {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.item-body {
  padding: 16rpx 0;
  border-top: 1rpx solid #f0f0f0;
  border-bottom: 1rpx solid #f0f0f0;
}

.body-row {
  display: flex;
  justify-content: space-between;
  padding: 12rpx 0;
}

.row-label {
  font-size: 26rpx;
  color: #999;
}

.row-value {
  font-size: 26rpx;
  color: #333;
}

.item-footer {
  margin-top: 16rpx;
}

.footer-btn {
  text-align: center;
  padding: 16rpx;
  background: #4A90D9;
  color: #fff;
  border-radius: 30rpx;
  font-size: 28rpx;
  
  &:active {
    opacity: 0.8;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}

.add-btn {
  position: fixed;
  bottom: 120rpx;
  left: 20rpx;
  right: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
