<template>
  <view class="profile-container">
    <view class="profile-header">
      <view class="user-card">
        <view class="avatar">
          <text class="avatar-text">管</text>
        </view>
        <view class="user-info">
          <text class="user-name">宿管管理员</text>
          <text class="user-id">工号：SG001</text>
        </view>
      </view>
    </view>

    <view class="menu-section">
      <view class="menu-card">
        <view class="menu-item" v-for="item in menuItems" :key="item.name" @click="handleMenu(item)">
          <view class="menu-icon">{{ item.icon }}</view>
          <text class="menu-text">{{ item.name }}</text>
          <text class="menu-arrow">›</text>
        </view>
      </view>
    </view>

    <view class="menu-section">
      <view class="menu-card">
        <view class="menu-item" @click="goToSettings">
          <view class="menu-icon">⚙️</view>
          <text class="menu-text">系统设置</text>
          <text class="menu-arrow">›</text>
        </view>
        <view class="menu-item" @click="goToAbout">
          <view class="menu-icon">ℹ️</view>
          <text class="menu-text">关于系统</text>
          <text class="menu-arrow">›</text>
        </view>
        <view class="menu-item" @click="goToHelp">
          <view class="menu-icon">❓</view>
          <text class="menu-text">帮助中心</text>
          <text class="menu-arrow">›</text>
        </view>
      </view>
    </view>

    <view class="logout-btn" @click="logout">
      <text>退出登录</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const menuItems = ref([
  { name: '数据统计', icon: '📊', action: 'stats' },
  { name: '值班记录', icon: '📋', action: 'duty' },
  { name: '请假审批', icon: '📝', action: 'leave' },
  { name: '卫生检查', icon: '🧹', action: 'clean' },
  { name: '物品登记', icon: '📦', action: 'items' },
  { name: '出入登记', icon: '🚪', action: 'access' }
])

function handleMenu(item: typeof menuItems.value[0]) {
  const routes: Record<string, string> = {
    stats: '/pages/profile/stats',
    duty: '/pages/profile/duty',
    leave: '/pages/profile/leave',
    clean: '/pages/profile/clean',
    items: '/pages/profile/items',
    access: '/pages/profile/access'
  }
  const url = routes[item.action]
  if (url) {
    uni.navigateTo({ url })
  }
}

function goToSettings() {
  uni.showModal({
    title: '系统设置',
    content: '1. 修改密码\n2. 通知设置\n3. 数据备份\n4. 系统更新',
    showCancel: false
  })
}

function goToAbout() {
  uni.showModal({
    title: '宿舍管理系统',
    content: '版本：v1.0.0\n\n为宿管老师提供便捷的宿舍管理服务\n\n技术支持：校园信息化中心',
    showCancel: false
  })
}

function goToHelp() {
  uni.showModal({
    title: '帮助中心',
    content: '如有疑问，请联系：\n电话：12345678900\n邮箱：dorm@school.edu.cn',
    showCancel: false
  })
}

function logout() {
  uni.showModal({
    title: '退出登录',
    content: '确定要退出登录吗？',
    success: (res) => {
      if (res.confirm) {
        uni.showToast({ title: '已退出', icon: 'none' })
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.profile-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.profile-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 80rpx 30rpx 40rpx;
}

.user-card {
  display: flex;
  align-items: center;
}

.avatar {
  width: 120rpx;
  height: 120rpx;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-text {
  color: #fff;
  font-size: 48rpx;
  font-weight: bold;
}

.user-info {
  flex: 1;
  margin-left: 24rpx;
}

.user-name {
  display: block;
  color: #fff;
  font-size: 36rpx;
  font-weight: bold;
}

.user-id {
  display: block;
  color: rgba(255, 255, 255, 0.8);
  font-size: 26rpx;
  margin-top: 8rpx;
}

.menu-section {
  padding: 20rpx;
}

.menu-card {
  background: #fff;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.menu-item {
  display: flex;
  align-items: center;
  padding: 28rpx 24rpx;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:active {
    background: #fafafa;
  }
}

.menu-icon {
  font-size: 36rpx;
  margin-right: 20rpx;
}

.menu-text {
  flex: 1;
  font-size: 30rpx;
  color: #333;
}

.menu-arrow {
  font-size: 32rpx;
  color: #999;
}

.logout-btn {
  margin: 40rpx 20rpx;
  padding: 28rpx;
  background: #fff;
  border: 2rpx solid #ddd;
  border-radius: 40rpx;
  text-align: center;
  font-size: 30rpx;
  color: #999;
  
  &:active {
    background: #f5f5f5;
  }
}
</style>
