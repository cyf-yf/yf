<template>
  <view class="access-container">
    <view class="access-header">
      <text class="access-title">出入登记</text>
    </view>

    <view class="quick-actions">
      <view class="action-item" @click="addAccess('in')">
        <text class="action-icon">🚪</text>
        <text class="action-text">进入登记</text>
      </view>
      <view class="action-item" @click="addAccess('out')">
        <text class="action-icon">🏃</text>
        <text class="action-text">外出登记</text>
      </view>
    </view>

    <view class="tabs">
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'all' }"
        @click="activeTab = 'all'"
      >全部</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'in' }"
        @click="activeTab = 'in'"
      >进入</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'out' }"
        @click="activeTab = 'out'"
      >外出</view>
    </view>

    <view class="access-list">
      <view class="access-item" v-for="record in filteredRecords" :key="record.id">
        <view class="access-icon" :class="record.type">
          {{ record.type === 'in' ? '🚪' : '🏃' }}
        </view>
        <view class="access-info">
          <view class="info-top">
            <text class="student-name">{{ record.studentName }}</text>
            <text class="access-type" :class="record.type">
              {{ record.type === 'in' ? '进入' : '外出' }}
            </text>
          </view>
          <view class="info-middle">
            <text class="dorm-info">{{ record.dormitory }}</text>
          </view>
          <view class="info-bottom">
            <text class="access-time">{{ record.time }}</text>
            <text class="access-reason">{{ record.reason }}</text>
          </view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredRecords.length === 0">
      <text class="empty-icon">🚶</text>
      <text class="empty-text">暂无{{ getTabText() }}登记记录</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

interface AccessRecord {
  id: string
  studentName: string
  dormitory: string
  type: 'in' | 'out'
  time: string
  reason: string
}

const activeTab = ref<'all' | 'in' | 'out'>('all')

const records = ref<AccessRecord[]>([
  { id: '1', studentName: '张小明', dormitory: '1号楼 302室', type: 'out', time: '2024-01-24 08:30', reason: '上课' },
  { id: '2', studentName: '李小红', dormitory: '2号楼 405室', type: 'out', time: '2024-01-24 08:35', reason: '上课' },
  { id: '3', studentName: '王小刚', dormitory: '1号楼 201室', type: 'in', time: '2024-01-24 08:40', reason: '返回宿舍' },
  { id: '4', studentName: '赵小丽', dormitory: '3号楼 506室', type: 'out', time: '2024-01-24 09:00', reason: '图书馆学习' },
  { id: '5', studentName: '孙小强', dormitory: '2号楼 303室', type: 'in', time: '2024-01-24 09:15', reason: '返回宿舍' },
  { id: '6', studentName: '周小美', dormitory: '4号楼 102室', type: 'out', time: '2024-01-24 09:30', reason: '食堂吃饭' },
  { id: '7', studentName: '吴小华', dormitory: '5号楼 601室', type: 'out', time: '2024-01-24 10:00', reason: '取快递' },
  { id: '8', studentName: '郑小杰', dormitory: '1号楼 404室', type: 'in', time: '2024-01-24 10:15', reason: '返回宿舍' }
])

const filteredRecords = computed(() => {
  if (activeTab.value === 'all') {
    return records.value
  }
  return records.value.filter(r => r.type === activeTab.value)
})

function getTabText() {
  const texts: Record<string, string> = {
    all: '',
    in: '进入',
    out: '外出'
  }
  return texts[activeTab.value] || ''
}

function addAccess(type: 'in' | 'out') {
  uni.showModal({
    title: type === 'in' ? '进入登记' : '外出登记',
    editable: true,
    placeholderText: `格式：学号/姓名 宿舍（如：张小明 1号楼302室）`,
    success: (res) => {
      if (res.confirm) {
        const content = res.content || ''
        const parts = content.split(' ')
        const name = parts[0] || '学生'
        const dorm = parts[1] || '未填写'
        
        const now = new Date()
        const time = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
        
        records.value.unshift({
          id: Date.now().toString(),
          studentName: name,
          dormitory: dorm,
          type: type,
          time: time,
          reason: type === 'in' ? '返回宿舍' : '外出'
        })
        
        uni.showToast({ title: '登记成功', icon: 'success' })
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.access-container {
  min-height: 100vh;
  background: #f5f5f5;
}

.access-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.access-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.quick-actions {
  display: flex;
  padding: 20rpx;
  gap: 20rpx;
  margin-top: -30rpx;
}

.action-item {
  flex: 1;
  background: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
  text-align: center;
  box-shadow: 0 4rpx 16rpx rgba(0, 0, 0, 0.1);
  
  &:active {
    opacity: 0.8;
  }
}

.action-icon {
  display: block;
  font-size: 56rpx;
  margin-bottom: 12rpx;
}

.action-text {
  font-size: 28rpx;
  color: #333;
  font-weight: bold;
}

.tabs {
  display: flex;
  background: #fff;
  padding: 0 20rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.tab-item {
  flex: 1;
  padding: 24rpx;
  text-align: center;
  font-size: 28rpx;
  color: #999;
  position: relative;
  
  &.active {
    color: #4A90D9;
    font-weight: bold;
    
    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 60rpx;
      height: 6rpx;
      background: #4A90D9;
      border-radius: 3rpx;
    }
  }
}

.access-list {
  padding: 20rpx;
}

.access-item {
  display: flex;
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 16rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.access-icon {
  font-size: 48rpx;
  margin-right: 20rpx;
  
  &.in {
    color: #52C41A;
  }
  
  &.out {
    color: #FF4D4F;
  }
}

.access-info {
  flex: 1;
}

.info-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8rpx;
}

.student-name {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.access-type {
  font-size: 24rpx;
  padding: 4rpx 16rpx;
  border-radius: 16rpx;
  
  &.in {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.out {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.info-middle {
  margin-bottom: 8rpx;
}

.dorm-info {
  font-size: 26rpx;
  color: #666;
}

.info-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.access-time {
  font-size: 24rpx;
  color: #999;
}

.access-reason {
  font-size: 24rpx;
  color: #4A90D9;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
