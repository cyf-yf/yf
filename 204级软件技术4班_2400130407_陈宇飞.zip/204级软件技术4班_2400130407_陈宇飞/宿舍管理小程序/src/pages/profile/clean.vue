<template>
  <view class="clean-container">
    <view class="clean-header">
      <text class="clean-title">卫生检查</text>
    </view>

    <view class="filter-bar">
      <picker mode="selector" :range="buildings" @change="onBuildingChange">
        <view class="picker-item">
          <text>{{ selectedBuilding || '选择楼栋' }}</text>
          <text class="picker-arrow">▼</text>
        </view>
      </picker>
      <picker mode="date" @change="onDateChange">
        <view class="picker-item">
          <text>{{ selectedDate || '选择日期' }}</text>
          <text class="picker-arrow">▼</text>
        </view>
      </picker>
    </view>

    <view class="stats-row">
      <view class="stat-item">
        <text class="stat-value">{{ stats.excellent }}</text>
        <text class="stat-label">优秀</text>
      </view>
      <view class="stat-item">
        <text class="stat-value">{{ stats.good }}</text>
        <text class="stat-label">良好</text>
      </view>
      <view class="stat-item">
        <text class="stat-value">{{ stats.pass }}</text>
        <text class="stat-label">合格</text>
      </view>
      <view class="stat-item">
        <text class="stat-value">{{ stats.fail }}</text>
        <text class="stat-label">不合格</text>
      </view>
    </view>

    <view class="clean-list">
      <view class="clean-item" v-for="item in cleanList" :key="item.id">
        <view class="item-header">
          <text class="dorm-name">{{ item.dormitory }}</text>
          <view class="score-badge" :class="getScoreClass(item.score)">
            {{ item.score }}分
          </view>
        </view>
        <view class="item-body">
          <view class="detail-row">
            <text class="detail-label">检查时间</text>
            <text class="detail-value">{{ item.checkTime }}</text>
          </view>
          <view class="detail-row">
            <text class="detail-label">检查人</text>
            <text class="detail-value">{{ item.checker }}</text>
          </view>
          <view class="detail-row">
            <text class="detail-label">备注</text>
            <text class="detail-value">{{ item.remark }}</text>
          </view>
        </view>
        <view class="item-footer" v-if="!item.checked">
          <view class="check-btn" @click="checkDorm(item)">立即检查</view>
        </view>
      </view>
    </view>

    <view class="add-btn" @click="addCheck">
      <text>+ 新增检查记录</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'

interface CleanItem {
  id: string
  dormitory: string
  score: number
  checkTime: string
  checker: string
  remark: string
  checked: boolean
}

const buildings = ['1号楼', '2号楼', '3号楼', '4号楼', '5号楼']
const selectedBuilding = ref('')
const selectedDate = ref('')

const stats = ref({
  excellent: 12,
  good: 28,
  pass: 8,
  fail: 2
})

const cleanList = ref<CleanItem[]>([
  { id: '1', dormitory: '1号楼 101室', score: 95, checkTime: '2024-01-24 09:30', checker: '管理员', remark: '非常干净整洁', checked: true },
  { id: '2', dormitory: '1号楼 102室', score: 88, checkTime: '2024-01-24 09:35', checker: '管理员', remark: '整体良好，地面干净', checked: true },
  { id: '3', dormitory: '1号楼 103室', score: 72, checkTime: '2024-01-24 09:40', checker: '管理员', remark: '桌面稍乱，需整理', checked: true },
  { id: '4', dormitory: '1号楼 104室', score: 0, checkTime: '', checker: '', remark: '未检查', checked: false },
  { id: '5', dormitory: '1号楼 201室', score: 92, checkTime: '2024-01-24 10:00', checker: '管理员', remark: '卫生状况良好', checked: true }
])

function getScoreClass(score: number) {
  if (score >= 90) return 'excellent'
  if (score >= 80) return 'good'
  if (score >= 60) return 'pass'
  return 'fail'
}

function onBuildingChange(e: any) {
  selectedBuilding.value = buildings[e.detail.value]
}

function onDateChange(e: any) {
  selectedDate.value = e.detail.value
}

function checkDorm(item: CleanItem) {
  uni.showModal({
    title: `检查 ${item.dormitory}`,
    editable: true,
    placeholderText: '请输入检查分数和备注',
    success: (res) => {
      if (res.confirm) {
        const now = new Date()
        const time = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
        
        const index = cleanList.value.findIndex(i => i.id === item.id)
        if (index !== -1) {
          const content = res.content || ''
          const match = content.match(/(\d+)/)
          const score = match ? parseInt(match[1]) : 85
          
          cleanList.value[index] = {
            ...item,
            score: score,
            checkTime: time,
            checker: '管理员',
            remark: content.replace(/\d+/g, '').trim() || '检查通过',
            checked: true
          }
        }
        
        uni.showToast({ title: '检查完成', icon: 'success' })
      }
    }
  })
}

function addCheck() {
  uni.showActionSheet({
    itemList: ['1号楼', '2号楼', '3号楼', '4号楼', '5号楼'],
    success: (res) => {
      const building = buildings[res.tapIndex]
      uni.showModal({
        title: `新增${building}检查记录`,
        editable: true,
        placeholderText: '格式：房间号 分数 备注（如：301 90 卫生良好）',
        success: (modalRes) => {
          if (modalRes.confirm) {
            const content = modalRes.content || ''
            const parts = content.split(' ')
            const roomNumber = parts[0] || '301'
            const score = parseInt(parts[1]) || 85
            const remark = parts.slice(2).join(' ') || '检查通过'
            
            const now = new Date()
            const time = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')} ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
            
            cleanList.value.unshift({
              id: Date.now().toString(),
              dormitory: `${building} ${roomNumber}室`,
              score: score,
              checkTime: time,
              checker: '管理员',
              remark: remark,
              checked: true
            })
            
            uni.showToast({ title: '记录成功', icon: 'success' })
          }
        }
      })
    }
  })
}
</script>

<style lang="scss" scoped>
.clean-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.clean-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.clean-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.filter-bar {
  display: flex;
  background: #fff;
  padding: 20rpx;
  gap: 20rpx;
}

.picker-item {
  flex: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
}

.picker-arrow {
  font-size: 20rpx;
  color: #999;
}

.stats-row {
  display: flex;
  padding: 20rpx;
  gap: 16rpx;
}

.stat-item {
  flex: 1;
  background: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  text-align: center;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.stat-value {
  display: block;
  font-size: 40rpx;
  font-weight: bold;
  color: #4A90D9;
}

.stat-label {
  display: block;
  font-size: 22rpx;
  color: #999;
  margin-top: 8rpx;
}

.clean-list {
  padding: 0 20rpx;
}

.clean-item {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.dorm-name {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.score-badge {
  font-size: 26rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
  font-weight: bold;
  
  &.excellent {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.good {
    background: #E6F7FF;
    color: #1890FF;
  }
  
  &.pass {
    background: #FFF7E6;
    color: #FAAD14;
  }
  
  &.fail {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.item-body {
  padding: 16rpx 0;
  border-top: 1rpx solid #f0f0f0;
  border-bottom: 1rpx solid #f0f0f0;
}

.detail-row {
  display: flex;
  justify-content: space-between;
  padding: 12rpx 0;
}

.detail-label {
  font-size: 26rpx;
  color: #999;
}

.detail-value {
  font-size: 26rpx;
  color: #333;
}

.item-footer {
  margin-top: 16rpx;
}

.check-btn {
  text-align: center;
  padding: 16rpx;
  background: #4A90D9;
  color: #fff;
  border-radius: 30rpx;
  font-size: 28rpx;
  
  &:active {
    opacity: 0.8;
  }
}

.add-btn {
  position: fixed;
  bottom: 120rpx;
  left: 20rpx;
  right: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
