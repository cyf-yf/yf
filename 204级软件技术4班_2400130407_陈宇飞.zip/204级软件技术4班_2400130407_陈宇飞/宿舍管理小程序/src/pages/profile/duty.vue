<template>
  <view class="duty-container">
    <view class="duty-header">
      <text class="duty-title">值班记录</text>
    </view>

    <view class="current-duty">
      <view class="duty-card">
        <view class="duty-date">
          <text class="date-label">今日值班</text>
          <text class="date-value">{{ currentDate }}</text>
        </view>
        <view class="duty-info">
          <text class="duty-name">宿管管理员</text>
          <text class="duty-time">08:00 - 20:00</text>
        </view>
        <view class="duty-status active">值班中</view>
      </view>
    </view>

    <view class="duty-section">
      <view class="section-header">
        <text class="section-title">本周排班</text>
        <text class="section-more">查看全部 ›</text>
      </view>
      <view class="week-calendar">
        <view class="calendar-item" v-for="day in weekDays" :key="day.date">
          <text class="day-name">{{ day.name }}</text>
          <text class="day-date">{{ day.date }}</text>
          <view class="day-status" :class="day.status">
            {{ day.status === 'duty' ? '值班' : day.status === 'rest' ? '休息' : '' }}
          </view>
        </view>
      </view>
    </view>

    <view class="duty-section">
      <view class="section-header">
        <text class="section-title">今日记录</text>
      </view>
      <view class="record-list">
        <view class="record-item" v-for="record in todayRecords" :key="record.id">
          <view class="record-icon">{{ record.icon }}</view>
          <view class="record-content">
            <text class="record-title">{{ record.title }}</text>
            <text class="record-time">{{ record.time }}</text>
          </view>
          <text class="record-arrow">›</text>
        </view>
      </view>
    </view>

    <view class="add-record-btn" @click="addRecord">
      <text>+ 添加记录</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

const currentDate = computed(() => {
  const date = new Date()
  return `${date.getMonth() + 1}月${date.getDate()}日 ${['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()]}`
})

const weekDays = ref([
  { name: '周一', date: '24', status: 'duty' },
  { name: '周二', date: '25', status: 'duty' },
  { name: '周三', date: '26', status: 'rest' },
  { name: '周四', date: '27', status: 'duty' },
  { name: '周五', date: '28', status: 'duty' },
  { name: '周六', date: '29', status: 'rest' },
  { name: '周日', date: '30', status: 'duty' }
])

const todayRecords = ref([
  { id: '1', icon: '👋', title: '早间巡查', time: '08:15', type: 'check' },
  { id: '2', icon: '📦', title: '学生物品登记', time: '10:30', type: 'register' },
  { id: '3', icon: '🔧', title: '处理报修申请', time: '14:20', type: 'repair' },
  { id: '4', icon: '👥', title: '新生入住办理', time: '15:45', type: 'checkin' }
])

function addRecord() {
  uni.showActionSheet({
    itemList: ['早间巡查', '晚间巡查', '物品登记', '出入登记', '报修处理', '其他'],
    success: (res) => {
      const types = ['早间巡查', '晚间巡查', '物品登记', '出入登记', '报修处理', '其他']
      const icons = ['👋', '🌙', '📦', '🚪', '🔧', '📝']
      const now = new Date()
      const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`
      
      todayRecords.value.unshift({
        id: Date.now().toString(),
        icon: icons[res.tapIndex],
        title: types[res.tapIndex],
        time: time,
        type: 'other'
      })
      
      uni.showToast({ title: '记录成功', icon: 'success' })
    }
  })
}
</script>

<style lang="scss" scoped>
.duty-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.duty-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.duty-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.current-duty {
  padding: 20rpx;
  margin-top: -20rpx;
}

.duty-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 4rpx 16rpx rgba(0, 0, 0, 0.1);
}

.duty-date {
  display: flex;
  justify-content: space-between;
  margin-bottom: 16rpx;
}

.date-label {
  font-size: 28rpx;
  color: #999;
}

.date-value {
  font-size: 28rpx;
  color: #333;
  font-weight: bold;
}

.duty-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.duty-name {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.duty-time {
  font-size: 26rpx;
  color: #666;
}

.duty-status {
  display: inline-block;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
  font-size: 24rpx;
  margin-top: 16rpx;
  
  &.active {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.rest {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.duty-section {
  margin: 20rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.section-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.section-more {
  font-size: 26rpx;
  color: #4A90D9;
}

.week-calendar {
  display: flex;
  justify-content: space-between;
}

.calendar-item {
  flex: 1;
  text-align: center;
  padding: 12rpx 0;
}

.day-name {
  display: block;
  font-size: 24rpx;
  color: #999;
}

.day-date {
  display: block;
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
  margin: 8rpx 0;
}

.day-status {
  font-size: 20rpx;
  padding: 4rpx 12rpx;
  border-radius: 12rpx;
  
  &.duty {
    background: #E6F7FF;
    color: #1890FF;
  }
  
  &.rest {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.record-list {
  display: flex;
  flex-direction: column;
}

.record-item {
  display: flex;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.record-icon {
  font-size: 36rpx;
  margin-right: 20rpx;
}

.record-content {
  flex: 1;
}

.record-title {
  display: block;
  font-size: 28rpx;
  color: #333;
}

.record-time {
  display: block;
  font-size: 24rpx;
  color: #999;
  margin-top: 4rpx;
}

.record-arrow {
  font-size: 32rpx;
  color: #999;
}

.add-record-btn {
  position: fixed;
  bottom: 120rpx;
  left: 20rpx;
  right: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
