<template>
  <view class="leave-container">
    <view class="leave-header">
      <text class="leave-title">请假审批</text>
    </view>

    <view class="tabs">
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'pending' }"
        @click="activeTab = 'pending'"
      >待审批</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'approved' }"
        @click="activeTab = 'approved'"
      >已批准</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'rejected' }"
        @click="activeTab = 'rejected'"
      >已拒绝</view>
    </view>

    <view class="leave-list">
      <view class="leave-item" v-for="leave in filteredLeaves" :key="leave.id" @click="viewLeave(leave)">
        <view class="leave-header">
          <view class="student-info">
            <view class="student-avatar">
              <text>{{ leave.studentName.charAt(0) }}</text>
            </view>
            <view class="student-detail">
              <text class="student-name">{{ leave.studentName }}</text>
              <text class="student-dorm">{{ leave.dormitory }}</text>
            </view>
          </view>
          <view class="leave-status" :class="leave.status">
            {{ getStatusText(leave.status) }}
          </view>
        </view>
        <view class="leave-body">
          <view class="leave-type">
            <text class="type-icon">{{ getTypeIcon(leave.type) }}</text>
            <text class="type-text">{{ getTypeText(leave.type) }}</text>
          </view>
          <view class="leave-time">
            <text>⏰ {{ leave.startTime }} ~ {{ leave.endTime }}</text>
          </view>
          <view class="leave-reason">
            <text>{{ leave.reason }}</text>
          </view>
        </view>
        <view class="leave-footer" v-if="leave.status === 'pending'">
          <view class="footer-btn reject" @click.stop="rejectLeave(leave)">拒绝</view>
          <view class="footer-btn approve" @click.stop="approveLeave(leave)">批准</view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredLeaves.length === 0">
      <text class="empty-icon">📭</text>
      <text class="empty-text">暂无{{ getTabText() }}请假申请</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'

interface Leave {
  id: string
  studentName: string
  dormitory: string
  type: 'leave' | 'late' | 'out'
  status: 'pending' | 'approved' | 'rejected'
  startTime: string
  endTime: string
  reason: string
}

const activeTab = ref<'pending' | 'approved' | 'rejected'>('pending')

const leaves = ref<Leave[]>([
  { id: '1', studentName: '张小明', dormitory: '1号楼 302室', type: 'leave', status: 'pending', startTime: '2024-01-24 08:00', endTime: '2024-01-26 18:00', reason: '家中有事，需要回家处理' },
  { id: '2', studentName: '李小红', dormitory: '2号楼 405室', type: 'late', status: 'pending', startTime: '2024-01-24 22:00', endTime: '2024-01-24 23:30', reason: '参加社团活动，预计晚归' },
  { id: '3', studentName: '王小刚', dormitory: '1号楼 201室', type: 'out', status: 'approved', startTime: '2024-01-23 09:00', endTime: '2024-01-23 18:00', reason: '外出就医' },
  { id: '4', studentName: '赵小丽', dormitory: '3号楼 506室', type: 'leave', status: 'approved', startTime: '2024-01-22 08:00', endTime: '2024-01-23 18:00', reason: '周末回家' },
  { id: '5', studentName: '孙小强', dormitory: '2号楼 303室', type: 'late', status: 'rejected', startTime: '2024-01-21 22:00', endTime: '2024-01-21 23:00', reason: '朋友聚会' }
])

const filteredLeaves = computed(() => {
  return leaves.value.filter(l => l.status === activeTab.value)
})

function getStatusText(status: string) {
  const texts: Record<string, string> = {
    pending: '待审批',
    approved: '已批准',
    rejected: '已拒绝'
  }
  return texts[status] || status
}

function getTypeText(type: string) {
  const texts: Record<string, string> = {
    leave: '请假',
    late: '晚归',
    out: '外出'
  }
  return texts[type] || type
}

function getTypeIcon(type: string) {
  const icons: Record<string, string> = {
    leave: '🏠',
    late: '🌙',
    out: '🚪'
  }
  return icons[type] || '📋'
}

function getTabText() {
  const texts: Record<string, string> = {
    pending: '',
    approved: '已批准的',
    rejected: '已拒绝的'
  }
  return texts[activeTab.value] || ''
}

function viewLeave(leave: Leave) {
  uni.showModal({
    title: `${leave.studentName}的${getTypeText(leave.type)}申请`,
    content: `宿舍：${leave.dormitory}\n时间：${leave.startTime} ~ ${leave.endTime}\n原因：${leave.reason}`,
    showCancel: false
  })
}

function approveLeave(leave: Leave) {
  uni.showModal({
    title: '批准申请',
    content: `确定批准${leave.studentName}的${getTypeText(leave.type)}申请吗？`,
    success: (res) => {
      if (res.confirm) {
        const index = leaves.value.findIndex(l => l.id === leave.id)
        if (index !== -1) {
          leaves.value[index].status = 'approved'
        }
        uni.showToast({ title: '已批准', icon: 'success' })
      }
    }
  })
}

function rejectLeave(leave: Leave) {
  uni.showModal({
    title: '拒绝申请',
    content: `确定拒绝${leave.studentName}的${getTypeText(leave.type)}申请吗？`,
    success: (res) => {
      if (res.confirm) {
        const index = leaves.value.findIndex(l => l.id === leave.id)
        if (index !== -1) {
          leaves.value[index].status = 'rejected'
        }
        uni.showToast({ title: '已拒绝', icon: 'none' })
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.leave-container {
  min-height: 100vh;
  background: #f5f5f5;
}

.leave-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
}

.leave-title {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.tabs {
  display: flex;
  background: #fff;
  padding: 0 20rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.tab-item {
  flex: 1;
  padding: 24rpx;
  text-align: center;
  font-size: 28rpx;
  color: #999;
  position: relative;
  
  &.active {
    color: #4A90D9;
    font-weight: bold;
    
    &::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 60rpx;
      height: 6rpx;
      background: #4A90D9;
      border-radius: 3rpx;
    }
  }
}

.leave-list {
  padding: 20rpx;
}

.leave-item {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.05);
}

.leave-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20rpx;
}

.student-info {
  display: flex;
  align-items: center;
}

.student-avatar {
  width: 72rpx;
  height: 72rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 32rpx;
  font-weight: bold;
}

.student-detail {
  margin-left: 16rpx;
}

.student-name {
  display: block;
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.student-dorm {
  display: block;
  font-size: 24rpx;
  color: #999;
}

.leave-status {
  font-size: 24rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
  
  &.pending {
    background: #FFF7E6;
    color: #FAAD14;
  }
  
  &.approved {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.rejected {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.leave-body {
  padding: 16rpx 0;
  border-top: 1rpx solid #f0f0f0;
  border-bottom: 1rpx solid #f0f0f0;
}

.leave-type {
  display: flex;
  align-items: center;
  margin-bottom: 12rpx;
}

.type-icon {
  font-size: 32rpx;
  margin-right: 12rpx;
}

.type-text {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
}

.leave-time {
  font-size: 26rpx;
  color: #666;
  margin-bottom: 12rpx;
}

.leave-reason {
  font-size: 26rpx;
  color: #999;
  line-height: 1.6;
}

.leave-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 20rpx;
}

.footer-btn {
  padding: 16rpx 32rpx;
  border-radius: 30rpx;
  font-size: 26rpx;
  margin-left: 16rpx;
  
  &.approve {
    background: #4A90D9;
    color: #fff;
  }
  
  &.reject {
    background: #f5f5f5;
    color: #666;
    border: 2rpx solid #ddd;
  }
  
  &:active {
    opacity: 0.8;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
