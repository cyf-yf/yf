<template>
  <view class="home-container">
    <view class="header">
      <view class="header-content">
        <view class="greeting">
          <text class="greeting-text">你好，宿管老师</text>
          <text class="greeting-date">{{ currentDate }}</text>
        </view>
        <view class="header-avatar">
          <text class="avatar-text">管</text>
        </view>
      </view>
    </view>

    <view class="banner-section">
      <swiper 
        class="banner-swiper" 
        indicator-dots="true" 
        autoplay="true" 
        interval="4000" 
        duration="500"
        circular="true"
        indicator-color="rgba(255,255,255,0.5)"
        indicator-active-color="#ffffff"
      >
        <swiper-item v-for="(banner, index) in banners" :key="index">
          <view class="banner-item" :style="{ background: banner.bg }">
            <view class="banner-content">
              <text class="banner-title">{{ banner.title }}</text>
              <text class="banner-desc">{{ banner.desc }}</text>
            </view>
          </view>
        </swiper-item>
      </swiper>
    </view>

    <view class="stats-section">
      <view class="stat-card" @click="goToDormitory">
        <view class="stat-icon">🏠</view>
        <view class="stat-info">
          <text class="stat-value">{{ dormCount }}</text>
          <text class="stat-label">宿舍总数</text>
        </view>
      </view>
      <view class="stat-card" @click="goToStudent">
        <view class="stat-icon">👥</view>
        <view class="stat-info">
          <text class="stat-value">{{ studentCount }}</text>
          <text class="stat-label">入住学生</text>
        </view>
      </view>
      <view class="stat-card" @click="goToMaintenance">
        <view class="stat-icon">🔧</view>
        <view class="stat-info">
          <text class="stat-value pending">{{ pendingMaintenance }}</text>
          <text class="stat-label">待处理报修</text>
        </view>
      </view>
      <view class="stat-card" @click="goToNotice">
        <view class="stat-icon">📢</view>
        <view class="stat-info">
          <text class="stat-value">{{ noticeCount }}</text>
          <text class="stat-label">今日通知</text>
        </view>
      </view>
    </view>

    <view class="quick-actions">
      <view class="section-header">
        <text class="section-title">快捷操作</text>
      </view>
      <view class="action-grid">
        <view class="action-item" v-for="item in actions" :key="item.name" @click="handleAction(item)">
          <view class="action-icon" :style="{ background: item.bg }">
            <text>{{ item.icon }}</text>
          </view>
          <text class="action-name">{{ item.name }}</text>
        </view>
      </view>
    </view>

    <view class="recent-section">
      <view class="section-header">
        <text class="section-title">待处理报修</text>
        <text class="section-more" @click="goToMaintenance">查看全部 ›</text>
      </view>
      <view class="maintenance-list">
        <view class="maintenance-item" v-for="item in pendingList" :key="item.id" @click="goToMaintenanceDetail(item.id)">
          <view class="item-header">
            <text class="item-title">{{ item.title }}</text>
            <view class="item-status pending">待处理</view>
          </view>
          <text class="item-desc">{{ item.dormitoryInfo }} · {{ item.studentName }}</text>
          <text class="item-time">{{ item.createTime }}</text>
        </view>
      </view>
    </view>

    <view class="recent-section">
      <view class="section-header">
        <text class="section-title">最新通知</text>
        <text class="section-more" @click="goToNotice">发布通知 ›</text>
      </view>
      <view class="notice-list">
        <view class="notice-item" v-for="notice in recentNotices" :key="notice.id">
          <view class="notice-type" :style="{ background: getTypeBg(notice.type), color: getTypeColor(notice.type) }">
            {{ getTypeLabel(notice.type) }}
          </view>
          <view class="notice-content">
            <text class="notice-title">{{ notice.title }}</text>
            <text class="notice-time">{{ notice.createTime }}</text>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { dormitories } from '@/data/dormitories'
import { maintenanceList } from '@/data/maintenance'
import { notices, typeLabels } from '@/data/notices'

const banners = ref([
  {
    title: '欢迎使用宿舍管理系统',
    desc: '一站式宿舍管理解决方案',
    bg: 'linear-gradient(135deg, #4A90D9 0%, #6BA3E0 100%)'
  },
  {
    title: '安全第一',
    desc: '定期检查宿舍安全设施',
    bg: 'linear-gradient(135deg, #52C41A 0%, #73D13D 100%)'
  },
  {
    title: '温馨提示',
    desc: '请按时完成卫生检查',
    bg: 'linear-gradient(135deg, #FAAD14 0%, #FFC53D 100%)'
  },
  {
    title: '报修服务',
    desc: '24小时在线报修处理',
    bg: 'linear-gradient(135deg, #FF4D4F 0%, #FF7875 100%)'
  }
])

const currentDate = computed(() => {
  const now = new Date()
  return `${now.getMonth() + 1}月${now.getDate()}日 ${['周日', '周一', '周二', '周三', '周四', '周五', '周六'][now.getDay()]}`
})

const dormCount = computed(() => dormitories.length)
const studentCount = computed(() => dormitories.reduce((sum, d) => sum + d.currentCount, 0))
const pendingMaintenance = computed(() => maintenanceList.filter(m => m.status === 'pending').length)
const noticeCount = computed(() => notices.filter(n => n.createTime.includes('2024-01-15')).length)

const pendingList = computed(() => maintenanceList.filter(m => m.status === 'pending').slice(0, 3))
const recentNotices = computed(() => notices.slice(0, 3))

const actions = ref([
  { name: '添加宿舍', icon: '🏠', bg: 'linear-gradient(135deg, #4A90D9, #6BA3E0)', action: 'addDormitory' },
  { name: '添加学生', icon: '👤', bg: 'linear-gradient(135deg, #52C41A, #73D13D)', action: 'addStudent' },
  { name: '发布通知', icon: '📢', bg: 'linear-gradient(135deg, #FAAD14, #FFC53D)', action: 'addNotice' },
  { name: '访客登记', icon: '🚪', bg: 'linear-gradient(135deg, #FF4D4F, #FF7875)', action: 'visitor' }
])

function getTypeLabel(type: string) {
  return typeLabels[type]?.label || '普通'
}

function getTypeBg(type: string) {
  return typeLabels[type]?.bgColor || '#E6F4FF'
}

function getTypeColor(type: string) {
  return typeLabels[type]?.color || '#4A90D9'
}

function goToDormitory() {
  uni.switchTab({ url: '/pages/dormitory/dormitory' })
}

function goToStudent() {
  uni.switchTab({ url: '/pages/student/student' })
}

function goToMaintenance() {
  uni.switchTab({ url: '/pages/maintenance/maintenance' })
}

function goToNotice() {
  uni.navigateTo({ url: '/pages/notice/add' })
}

function goToMaintenanceDetail(id: string) {
  uni.navigateTo({ url: `/pages/maintenance/detail?id=${id}` })
}

function handleAction(item: typeof actions.value[0]) {
  switch (item.action) {
    case 'addDormitory':
      uni.navigateTo({ url: '/pages/dormitory/add' })
      break
    case 'addStudent':
      uni.navigateTo({ url: '/pages/student/add' })
      break
    case 'addNotice':
      uni.navigateTo({ url: '/pages/notice/add' })
      break
    case 'visitor':
      uni.showModal({
        title: '访客登记',
        content: '请登记访客信息：\n姓名：\n身份证号：\n来访时间：\n离开时间：',
        showCancel: false
      })
      break
  }
}
</script>

<style lang="scss" scoped>
.home-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 80rpx 30rpx 40rpx;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.greeting-text {
  display: block;
  color: #fff;
  font-size: 36rpx;
  font-weight: bold;
}

.banner-section {
  padding: 20rpx;
}

.banner-swiper {
  height: 320rpx;
  border-radius: 20rpx;
  overflow: hidden;
}

.banner-item {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 20rpx;
}

.banner-content {
  text-align: center;
  padding: 40rpx;
}

.banner-title {
  display: block;
  color: #fff;
  font-size: 40rpx;
  font-weight: bold;
  margin-bottom: 16rpx;
  text-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.2);
}

.banner-desc {
  display: block;
  color: rgba(255, 255, 255, 0.9);
  font-size: 28rpx;
  text-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.2);
}

.greeting-date {
  display: block;
  color: rgba(255, 255, 255, 0.8);
  font-size: 26rpx;
  margin-top: 8rpx;
}

.header-avatar {
  width: 80rpx;
  height: 80rpx;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.avatar-text {
  color: #fff;
  font-size: 32rpx;
  font-weight: bold;
}

.stats-section {
  display: flex;
  margin: -20rpx 20rpx 20rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.stat-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16rpx 0;
  
  &:active {
    opacity: 0.7;
  }
}

.stat-icon {
  font-size: 40rpx;
  margin-bottom: 12rpx;
}

.stat-info {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.stat-value {
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  
  &.pending {
    color: #FAAD14;
  }
}

.stat-label {
  font-size: 22rpx;
  color: #999;
  margin-top: 6rpx;
}

.quick-actions {
  margin: 0 20rpx 20rpx;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.section-title {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.section-more {
  font-size: 24rpx;
  color: #4A90D9;
}

.action-grid {
  display: flex;
  background: #fff;
  border-radius: 16rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.action-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16rpx 0;
  
  &:active {
    opacity: 0.7;
  }
}

.action-icon {
  width: 80rpx;
  height: 80rpx;
  border-radius: 20rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 40rpx;
}

.action-name {
  font-size: 24rpx;
  color: #666;
  margin-top: 12rpx;
}

.recent-section {
  margin: 0 20rpx 20rpx;
}

.maintenance-list {
  background: #fff;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.maintenance-item {
  padding: 20rpx 24rpx;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
  
  &:active {
    background: #fafafa;
  }
}

.item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8rpx;
}

.item-title {
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
}

.item-status {
  font-size: 22rpx;
  padding: 4rpx 12rpx;
  border-radius: 12rpx;
  
  &.pending {
    background: #FFF7E6;
    color: #FAAD14;
  }
}

.item-desc {
  display: block;
  font-size: 24rpx;
  color: #666;
  margin-bottom: 8rpx;
}

.item-time {
  display: block;
  font-size: 22rpx;
  color: #999;
}

.notice-list {
  background: #fff;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.notice-item {
  display: flex;
  align-items: center;
  padding: 20rpx 24rpx;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.notice-type {
  font-size: 22rpx;
  padding: 6rpx 12rpx;
  border-radius: 12rpx;
  margin-right: 16rpx;
}

.notice-content {
  flex: 1;
}

.notice-title {
  display: block;
  font-size: 26rpx;
  color: #333;
}

.notice-time {
  display: block;
  font-size: 22rpx;
  color: #999;
  margin-top: 6rpx;
}
</style>
