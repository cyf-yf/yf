<template>
  <view class="dormitory-container">
    <view class="search-bar">
      <view class="search-input-wrap">
        <text class="search-icon">🔍</text>
        <input class="search-input" placeholder="搜索宿舍号或楼栋" v-model="searchText" />
      </view>
      <view class="add-btn" @click="goToAdd">
        <text>+ 添加</text>
      </view>
    </view>

    <view class="filter-section">
      <view class="filter-row">
        <text class="filter-label">楼栋</text>
        <view class="filter-options">
          <view 
            class="filter-option" 
            :class="{ active: selectedBuilding === '' }"
            @click="selectedBuilding = ''"
          >全部</view>
          <view 
            class="filter-option" 
            v-for="building in buildings" 
            :key="building"
            :class="{ active: selectedBuilding === building }"
            @click="selectedBuilding = building"
          >{{ building }}</view>
        </view>
      </view>
      <view class="filter-row">
        <text class="filter-label">状态</text>
        <view class="filter-options">
          <view 
            class="filter-option" 
            :class="{ active: selectedStatus === '' }"
            @click="selectedStatus = ''"
          >全部</view>
          <view 
            class="filter-option" 
            :class="{ active: selectedStatus === 'available' }"
            @click="selectedStatus = 'available'"
          >有空位</view>
          <view 
            class="filter-option" 
            :class="{ active: selectedStatus === 'full' }"
            @click="selectedStatus = 'full'"
          >已满</view>
          <view 
            class="filter-option" 
            :class="{ active: selectedStatus === 'maintenance' }"
            @click="selectedStatus = 'maintenance'"
          >维修中</view>
        </view>
      </view>
    </view>

    <view class="dorm-list">
      <view class="dorm-card" v-for="dorm in filteredDorms" :key="dorm.id">
        <view class="card-content" @click="goToDetail(dorm.id)">
          <view class="dorm-header">
            <view class="dorm-info">
              <text class="dorm-building">{{ dorm.building }}</text>
              <text class="dorm-number">{{ dorm.roomNumber }}室</text>
            </view>
            <view class="dorm-status-tag" :class="dorm.status">
              {{ getStatusLabel(dorm.status) }}
            </view>
          </view>
          <view class="dorm-body">
            <view class="dorm-meta">
              <view class="meta-item">
                <text class="meta-icon">👥</text>
                <text class="meta-text">{{ dorm.currentCount }}/{{ dorm.capacity }}人</text>
              </view>
              <view class="meta-item">
                <text class="meta-icon">🚻</text>
                <text class="meta-text">{{ getTypeLabel(dorm.type) }}</text>
              </view>
              <view class="meta-item">
                <text class="meta-icon">🏢</text>
                <text class="meta-text">{{ dorm.floor }}层</text>
              </view>
            </view>
            <view class="progress-bar">
              <view class="progress-fill" :style="{ width: getProgressWidth(dorm) + '%' }"></view>
            </view>
            <view class="roommates">
              <view class="roommate-avatar" v-for="(student, index) in dorm.students.slice(0, 4)" :key="index">
                <text>{{ student.name.charAt(0) }}</text>
              </view>
              <view class="roommate-more" v-if="dorm.students.length > 4">
                <text>+{{ dorm.students.length - 4 }}</text>
              </view>
            </view>
          </view>
        </view>
        <view class="card-actions">
          <view class="action-btn edit" @click="editDorm(dorm.id)">
            <text>编辑</text>
          </view>
          <view class="action-btn delete" @click="deleteDorm(dorm)">
            <text>删除</text>
          </view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredDorms.length === 0">
      <text class="empty-icon">🏠</text>
      <text class="empty-text">没有找到符合条件的宿舍</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { dormitories as initialDorms, type Dormitory } from '@/data/dormitories'

const searchText = ref('')
const selectedBuilding = ref('')
const selectedStatus = ref('')
const dormitories = ref<Dormitory[]>([...initialDorms])

const buildings = computed(() => {
  const set = new Set(dormitories.value.map(d => d.building))
  return Array.from(set)
})

const filteredDorms = computed(() => {
  return dormitories.value.filter(dorm => {
    const matchSearch = !searchText.value || 
      dorm.roomNumber.includes(searchText.value) || 
      dorm.building.includes(searchText.value)
    const matchBuilding = !selectedBuilding.value || dorm.building === selectedBuilding.value
    const matchStatus = !selectedStatus.value || dorm.status === selectedStatus.value
    return matchSearch && matchBuilding && matchStatus
  })
})

function getStatusLabel(status: string) {
  const labels: Record<string, string> = {
    available: '有空位',
    full: '已满',
    maintenance: '维修中'
  }
  return labels[status] || status
}

function getTypeLabel(type: string) {
  const labels: Record<string, string> = {
    male: '男生',
    female: '女生',
    mixed: '混合'
  }
  return labels[type] || type
}

function getProgressWidth(dorm: typeof initialDorms[0]) {
  return Math.round((dorm.currentCount / dorm.capacity) * 100)
}

function goToAdd() {
  uni.navigateTo({ url: '/pages/dormitory/add' })
}

function goToDetail(id: string) {
  uni.navigateTo({ url: `/pages/dormitory/detail?id=${id}` })
}

function editDorm(id: string) {
  uni.navigateTo({ url: `/pages/dormitory/add?id=${id}` })
}

function deleteDorm(dorm: Dormitory) {
  uni.showModal({
    title: '删除宿舍',
    content: `确定要删除宿舍「${dorm.building}${dorm.roomNumber}室」吗？`,
    success: (res) => {
      if (res.confirm) {
        const index = dormitories.value.findIndex(d => d.id === dorm.id)
        if (index !== -1) {
          dormitories.value.splice(index, 1)
        }
        uni.showToast({ title: '删除成功', icon: 'success' })
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.dormitory-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.search-bar {
  display: flex;
  padding: 20rpx;
  background: #fff;
}

.search-input-wrap {
  flex: 1;
  display: flex;
  align-items: center;
  background: #f5f5f5;
  border-radius: 40rpx;
  padding: 16rpx 24rpx;
}

.search-icon {
  font-size: 32rpx;
  margin-right: 12rpx;
}

.search-input {
  flex: 1;
  font-size: 28rpx;
}

.add-btn {
  margin-left: 20rpx;
  padding: 16rpx 24rpx;
  background: #4A90D9;
  color: #fff;
  border-radius: 40rpx;
  font-size: 28rpx;
}

.filter-section {
  background: #fff;
  padding: 16rpx 20rpx;
  border-top: 1rpx solid #f0f0f0;
}

.filter-row {
  margin-bottom: 16rpx;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.filter-label {
  font-size: 26rpx;
  color: #666;
  margin-bottom: 12rpx;
  display: block;
}

.filter-options {
  display: flex;
  flex-wrap: wrap;
}

.filter-option {
  padding: 12rpx 24rpx;
  background: #f5f5f5;
  border-radius: 20rpx;
  font-size: 26rpx;
  margin-right: 16rpx;
  margin-bottom: 12rpx;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.dorm-list {
  padding: 20rpx;
}

.dorm-card {
  background: #fff;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.card-content {
  padding: 24rpx;
  
  &:active {
    background: #fafafa;
  }
}

.dorm-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.dorm-info {
  display: flex;
  align-items: baseline;
}

.dorm-building {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.dorm-number {
  font-size: 28rpx;
  color: #666;
  margin-left: 8rpx;
}

.dorm-status-tag {
  font-size: 22rpx;
  padding: 6rpx 16rpx;
  border-radius: 20rpx;
  
  &.available {
    background: #E6F7FF;
    color: #4A90D9;
  }
  
  &.full {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.maintenance {
    background: #FFF7E6;
    color: #FAAD14;
  }
}

.dorm-body {
  border-top: 1rpx solid #f0f0f0;
  padding-top: 16rpx;
}

.dorm-meta {
  display: flex;
  margin-bottom: 16rpx;
}

.meta-item {
  display: flex;
  align-items: center;
  margin-right: 32rpx;
}

.meta-icon {
  font-size: 28rpx;
  margin-right: 8rpx;
}

.meta-text {
  font-size: 26rpx;
  color: #666;
}

.progress-bar {
  height: 8rpx;
  background: #f0f0f0;
  border-radius: 4rpx;
  overflow: hidden;
  margin-bottom: 16rpx;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #4A90D9, #6BA3E0);
  border-radius: 4rpx;
}

.roommates {
  display: flex;
  align-items: center;
}

.roommate-avatar {
  width: 48rpx;
  height: 48rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 22rpx;
  margin-right: -10rpx;
  border: 2rpx solid #fff;
  
  &:first-child {
    margin-right: 0;
  }
}

.roommate-more {
  width: 48rpx;
  height: 48rpx;
  background: #f0f0f0;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18rpx;
  color: #999;
  margin-left: 8rpx;
  border: 2rpx solid #fff;
}

.card-actions {
  display: flex;
  border-top: 1rpx solid #f0f0f0;
}

.action-btn {
  flex: 1;
  padding: 20rpx;
  text-align: center;
  font-size: 28rpx;
  
  &.edit {
    background: #E6F7FF;
    color: #4A90D9;
    border-right: 1rpx solid #f0f0f0;
  }
  
  &.delete {
    background: #FFF1F0;
    color: #FF4D4F;
  }
  
  &:active {
    opacity: 0.7;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
