<template>
  <view class="add-container">
    <view class="form-card">
      <view class="form-item">
        <text class="form-label">楼栋 *</text>
        <input class="form-input" placeholder="如：1号楼" v-model="formData.building" />
      </view>

      <view class="form-item">
        <text class="form-label">房间号 *</text>
        <input class="form-input" placeholder="如：101" v-model="formData.roomNumber" />
      </view>

      <view class="form-item">
        <text class="form-label">楼层 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="floor in floors" 
            :key="floor"
            :class="{ active: formData.floor === floor }"
            @click="formData.floor = floor"
          >{{ floor }}层</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">宿舍类型 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'male' }"
            @click="formData.type = 'male'"
          >男生</view>
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'female' }"
            @click="formData.type = 'female'"
          >女生</view>
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'mixed' }"
            @click="formData.type = 'mixed'"
          >混合</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">容量 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="cap in capacities" 
            :key="cap"
            :class="{ active: formData.capacity === cap }"
            @click="formData.capacity = cap"
          >{{ cap }}人</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">状态 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            :class="{ active: formData.status === 'available' }"
            @click="formData.status = 'available'"
          >有空位</view>
          <view 
            class="type-option" 
            :class="{ active: formData.status === 'full' }"
            @click="formData.status = 'full'"
          >已满</view>
          <view 
            class="type-option" 
            :class="{ active: formData.status === 'maintenance' }"
            @click="formData.status = 'maintenance'"
          >维修中</view>
        </view>
      </view>
    </view>

    <view class="submit-btn" @click="submitForm">
      <text>{{ isEdit ? '保存修改' : '添加宿舍' }}</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

const isEdit = ref(false)
const floors = [1, 2, 3, 4, 5, 6, 7, 8]
const capacities = [4, 6, 8]

const formData = reactive({
  building: '',
  roomNumber: '',
  floor: 1,
  type: 'male' as 'male' | 'female' | 'mixed',
  capacity: 4,
  currentCount: 0,
  status: 'available' as 'available' | 'full' | 'maintenance'
})

onLoad((options) => {
  if (options?.id) {
    isEdit.value = true
    formData.building = '1号楼'
    formData.roomNumber = '101'
    formData.floor = 1
    formData.type = 'male'
    formData.capacity = 4
    formData.currentCount = 3
    formData.status = 'available'
  }
})

function submitForm() {
  if (!formData.building) {
    uni.showToast({ title: '请输入楼栋', icon: 'none' })
    return
  }
  if (!formData.roomNumber) {
    uni.showToast({ title: '请输入房间号', icon: 'none' })
    return
  }
  
  uni.showLoading({ title: '提交中...' })
  
  setTimeout(() => {
    uni.hideLoading()
    uni.showToast({ title: isEdit.value ? '修改成功' : '添加成功', icon: 'success' })
    setTimeout(() => {
      uni.navigateBack()
    }, 1500)
  }, 1000)
}
</script>

<style lang="scss" scoped>
.add-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.form-card {
  background: #fff;
  margin: 20rpx;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.form-item {
  margin-bottom: 24rpx;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.form-label {
  font-size: 28rpx;
  color: #333;
  margin-bottom: 12rpx;
  display: block;
}

.form-input {
  width: 100%;
  padding: 24rpx 20rpx;
  background: #fff;
  border: 2rpx solid #e8e8e8;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
  
  &:focus {
    border-color: #4A90D9;
    outline: none;
    box-shadow: 0 0 0 4rpx rgba(74, 144, 217, 0.1);
  }
}

.type-options {
  display: flex;
  flex-wrap: wrap;
}

.type-option {
  padding: 16rpx 24rpx;
  background: #f5f5f5;
  border-radius: 20rpx;
  font-size: 26rpx;
  color: #666;
  margin-right: 16rpx;
  margin-bottom: 12rpx;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.submit-btn {
  margin: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
