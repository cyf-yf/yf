<template>
  <view class="detail-container">
    <view class="detail-header">
      <view class="dorm-title">
        <text class="dorm-name">{{ dorm?.building }} {{ dorm?.roomNumber }}室</text>
        <view class="dorm-status" :class="dorm?.status">
          {{ getStatusLabel(dorm?.status) }}
        </view>
      </view>
      <view class="dorm-badge">
        <text class="badge-text">{{ getTypeLabel(dorm?.type) }}宿舍</text>
      </view>
    </view>

    <view class="detail-body">
      <view class="info-card">
        <view class="info-title">
          <text class="title-icon">📊</text>
          <text class="title-text">宿舍信息</text>
        </view>
        <view class="info-grid">
          <view class="info-item">
            <text class="info-value">{{ dorm?.floor }}层</text>
            <text class="info-label">楼层</text>
          </view>
          <view class="info-item">
            <text class="info-value">{{ dorm?.capacity }}人</text>
            <text class="info-label">容量</text>
          </view>
          <view class="info-item">
            <text class="info-value">{{ dorm?.currentCount }}人</text>
            <text class="info-label">已入住</text>
          </view>
          <view class="info-item">
            <text class="info-value">{{ getEmptyBeds() }}个</text>
            <text class="info-label">空床位</text>
          </view>
        </view>
      </view>

      <view class="students-card">
        <view class="info-title">
          <text class="title-icon">👥</text>
          <text class="title-text">室友列表</text>
          <text class="title-count">{{ dorm?.students.length }}人</text>
        </view>
        <view class="students-list">
          <view class="student-item" v-for="student in dorm?.students" :key="student.id">
            <view class="student-avatar">
              <text>{{ student.name.charAt(0) }}</text>
            </view>
            <view class="student-info">
              <text class="student-name">{{ student.name }}</text>
              <text class="student-detail">{{ student.grade }} · {{ student.major }} · {{ student.bedNumber }}号床</text>
            </view>
          </view>
        </view>
      </view>

      <view class="facilities-card">
        <view class="info-title">
          <text class="title-icon">🛠️</text>
          <text class="title-text">设施配置</text>
        </view>
        <view class="facilities-grid">
          <view class="facility-item" v-for="(facility, index) in facilities" :key="index">
            <view class="facility-icon">{{ facility.icon }}</view>
            <text class="facility-name">{{ facility.name }}</text>
          </view>
        </view>
      </view>

      <view class="rules-card">
        <view class="info-title">
          <text class="title-icon">📋</text>
          <text class="title-text">宿舍规则</text>
        </view>
        <view class="rules-list">
          <view class="rule-item" v-for="(rule, index) in rules" :key="index">
            <view class="rule-num">{{ index + 1 }}</view>
            <text class="rule-text">{{ rule }}</text>
          </view>
        </view>
      </view>
    </view>

    <view class="detail-footer">
      <view class="footer-btn secondary" @click="goBack">
        <text>返回</text>
      </view>
      <view class="footer-btn primary" v-if="dorm?.status === 'available'" @click="apply">
        <text>申请入住</text>
      </view>
      <view class="footer-btn primary" v-else @click="contact">
        <text>联系宿管</text>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { getDormitoryById, type Dormitory } from '@/data/dormitories'

const dorm = ref<Dormitory | null>(null)

const facilities = ref([
  { icon: '🛏️', name: '床位' },
  { icon: '🖥️', name: '书桌' },
  { icon: '🗄️', name: '衣柜' },
  { icon: '🪟', name: '窗户' },
  { icon: '❄️', name: '空调' },
  { icon: '💡', name: '电灯' },
  { icon: '🚿', name: '卫生间' },
  { icon: '🔥', name: '热水器' }
])

const rules = ref([
  '遵守学校作息时间，晚上11点后保持安静',
  '禁止使用大功率电器，确保用电安全',
  '保持宿舍卫生整洁，定期打扫',
  '爱护公共设施，损坏需赔偿',
  '禁止私自调换床位或留宿外人',
  '离开宿舍时关好门窗和电源'
])

onLoad((options) => {
  const id = options?.id || '1'
  dorm.value = getDormitoryById(id) || null
})

function getStatusLabel(status?: string) {
  const labels: Record<string, string> = {
    available: '有空位',
    full: '已满',
    maintenance: '维修中'
  }
  return labels[status || ''] || ''
}

function getTypeLabel(type?: string) {
  const labels: Record<string, string> = {
    male: '男生',
    female: '女生',
    mixed: '混合'
  }
  return labels[type || ''] || ''
}

function getEmptyBeds() {
  if (!dorm.value) return 0
  return dorm.value.capacity - dorm.value.currentCount
}

function goBack() {
  uni.navigateBack()
}

function apply() {
  uni.showModal({
    title: '申请入住',
    content: `确定要申请入住${dorm.value?.building}${dorm.value?.roomNumber}室吗？`,
    success: (res) => {
      if (res.confirm) {
        uni.showToast({ title: '申请提交成功', icon: 'success' })
        setTimeout(() => {
          uni.navigateBack()
        }, 1500)
      }
    }
  })
}

function contact() {
  uni.showModal({
    title: '联系宿管',
    content: '宿管电话：12345678900',
    showCancel: false
  })
}
</script>

<style lang="scss" scoped>
.detail-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.detail-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 30rpx;
}

.dorm-title {
  display: flex;
  align-items: center;
  margin-bottom: 16rpx;
}

.dorm-name {
  font-size: 36rpx;
  font-weight: bold;
  color: #fff;
}

.dorm-status {
  font-size: 22rpx;
  padding: 6rpx 16rpx;
  border-radius: 20rpx;
  margin-left: 16rpx;
  
  &.available {
    background: rgba(255, 255, 255, 0.3);
    color: #fff;
  }
  
  &.full {
    background: rgba(82, 196, 26, 0.8);
    color: #fff;
  }
  
  &.maintenance {
    background: rgba(250, 173, 20, 0.8);
    color: #fff;
  }
}

.dorm-badge {
  background: rgba(255, 255, 255, 0.2);
  border-radius: 20rpx;
  padding: 8rpx 20rpx;
  display: inline-block;
}

.badge-text {
  color: #fff;
  font-size: 24rpx;
}

.detail-body {
  padding: 20rpx;
}

.info-card, .students-card, .facilities-card, .rules-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.info-title {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
}

.title-icon {
  font-size: 32rpx;
  margin-right: 12rpx;
}

.title-text {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.title-count {
  font-size: 24rpx;
  color: #999;
  margin-left: auto;
}

.info-grid {
  display: flex;
  flex-wrap: wrap;
}

.info-item {
  width: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16rpx 0;
}

.info-value {
  font-size: 40rpx;
  font-weight: bold;
  color: #4A90D9;
}

.info-label {
  font-size: 24rpx;
  color: #999;
  margin-top: 8rpx;
}

.students-list {
  display: flex;
  flex-direction: column;
}

.student-item {
  display: flex;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.student-avatar {
  width: 80rpx;
  height: 80rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 32rpx;
  font-weight: bold;
}

.student-info {
  flex: 1;
  margin-left: 20rpx;
}

.student-name {
  display: block;
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
}

.student-detail {
  display: block;
  font-size: 24rpx;
  color: #999;
  margin-top: 8rpx;
}

.facilities-grid {
  display: flex;
  flex-wrap: wrap;
}

.facility-item {
  width: 25%;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20rpx 0;
}

.facility-icon {
  font-size: 40rpx;
  margin-bottom: 8rpx;
}

.facility-name {
  font-size: 24rpx;
  color: #666;
}

.rules-list {
  display: flex;
  flex-direction: column;
}

.rule-item {
  display: flex;
  padding: 12rpx 0;
}

.rule-num {
  width: 40rpx;
  height: 40rpx;
  background: #4A90D9;
  color: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22rpx;
  font-weight: bold;
  margin-right: 16rpx;
  flex-shrink: 0;
}

.rule-text {
  font-size: 26rpx;
  color: #666;
  line-height: 1.6;
}

.detail-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  padding: 20rpx;
  background: #fff;
  box-shadow: 0 -2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.footer-btn {
  flex: 1;
  padding: 24rpx;
  border-radius: 40rpx;
  text-align: center;
  font-size: 30rpx;
  
  &.primary {
    background: linear-gradient(135deg, #4A90D9, #6BA3E0);
    color: #fff;
    margin-left: 20rpx;
  }
  
  &.secondary {
    background: #f5f5f5;
    color: #666;
  }
  
  &:active {
    opacity: 0.8;
  }
}
</style>
