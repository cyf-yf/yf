<template>
  <view class="add-container">
    <view class="form-card">
      <view class="form-item">
        <text class="form-label">报修类型 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="type in maintenanceTypes" 
            :key="type.value"
            :class="{ active: formData.type === type.value }"
            @click="formData.type = type.value"
          >
            {{ type.label }}
          </view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">报修标题 *</text>
        <input class="form-input" placeholder="请输入报修标题" v-model="formData.title" />
      </view>

      <view class="form-item">
        <text class="form-label">详细描述 *</text>
        <textarea 
          class="form-textarea" 
          placeholder="请详细描述问题情况..." 
          v-model="formData.description"
        ></textarea>
      </view>

      <view class="form-item">
        <text class="form-label">所在宿舍 *</text>
        <view class="dorm-select" @click="showDormPicker = true">
          <text class="select-text">{{ formData.dormitoryInfo || '请选择宿舍' }}</text>
          <text class="select-arrow">›</text>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">报修人 *</text>
        <input class="form-input" placeholder="请输入姓名" v-model="formData.studentName" />
      </view>

      <view class="form-item">
        <text class="form-label">联系方式</text>
        <input class="form-input" placeholder="请输入联系电话" v-model="formData.phone" type="number" />
      </view>
    </view>

    <view class="submit-btn" @click="submitForm">
      <text>提交报修</text>
    </view>

    <view class="dorm-picker" v-if="showDormPicker" @click="showDormPicker = false">
      <view class="picker-content" @click.stop>
        <view class="picker-header">
          <text class="picker-title">选择宿舍</text>
          <text class="picker-close" @click="showDormPicker = false">✕</text>
        </view>
        <scroll-view class="picker-list" scroll-y>
          <view 
            class="picker-item" 
            v-for="dorm in dormitories" 
            :key="dorm.id"
            :class="{ active: formData.dormitoryId === dorm.id }"
            @click="selectDorm(dorm)"
          >
            <text class="dorm-name">{{ dorm.building }} {{ dorm.roomNumber }}室</text>
            <view class="dorm-status" :class="dorm.status">{{ getDormStatus(dorm.status) }}</view>
          </view>
        </scroll-view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { maintenanceTypes } from '@/data/maintenance'
import { dormitories } from '@/data/dormitories'

const showDormPicker = ref(false)

const formData = reactive({
  type: '',
  title: '',
  description: '',
  dormitoryId: '',
  dormitoryInfo: '',
  studentName: '',
  phone: ''
})

function getDormStatus(status: string) {
  const labels: Record<string, string> = {
    available: '有空位',
    full: '已满',
    maintenance: '维修中'
  }
  return labels[status] || status
}

function selectDorm(dorm: typeof dormitories[0]) {
  formData.dormitoryId = dorm.id
  formData.dormitoryInfo = `${dorm.building} ${dorm.roomNumber}室`
  showDormPicker.value = false
}

function submitForm() {
  if (!formData.type) {
    uni.showToast({ title: '请选择报修类型', icon: 'none' })
    return
  }
  if (!formData.title) {
    uni.showToast({ title: '请输入报修标题', icon: 'none' })
    return
  }
  if (!formData.description) {
    uni.showToast({ title: '请输入详细描述', icon: 'none' })
    return
  }
  if (!formData.dormitoryId) {
    uni.showToast({ title: '请选择宿舍', icon: 'none' })
    return
  }
  if (!formData.studentName) {
    uni.showToast({ title: '请输入姓名', icon: 'none' })
    return
  }
  
  uni.showLoading({ title: '提交中...' })
  
  setTimeout(() => {
    uni.hideLoading()
    uni.showToast({ title: '提交成功', icon: 'success' })
    setTimeout(() => {
      uni.navigateBack()
    }, 1500)
  }, 1000)
}
</script>

<style lang="scss" scoped>
.add-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.form-card {
  background: #fff;
  margin: 20rpx;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.form-item {
  margin-bottom: 24rpx;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.form-label {
  font-size: 28rpx;
  color: #333;
  margin-bottom: 12rpx;
  display: block;
}

.type-options {
  display: flex;
  flex-wrap: wrap;
}

.type-option {
  padding: 16rpx 24rpx;
  background: #f5f5f5;
  border-radius: 20rpx;
  font-size: 26rpx;
  color: #666;
  margin-right: 16rpx;
  margin-bottom: 12rpx;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.form-input {
  width: 100%;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
}

.form-textarea {
  width: 100%;
  height: 200rpx;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
}

.dorm-select {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
}

.select-text {
  font-size: 28rpx;
  color: #666;
}

.select-arrow {
  font-size: 36rpx;
  color: #999;
}

.submit-btn {
  margin: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}

.dorm-picker {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  z-index: 1000;
}

.picker-content {
  width: 100%;
  background: #fff;
  border-radius: 24rpx 24rpx 0 0;
  max-height: 70vh;
}

.picker-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.picker-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.picker-close {
  font-size: 36rpx;
  color: #999;
}

.picker-list {
  max-height: 60vh;
}

.picker-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24rpx 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
  
  &.active {
    background: #E6F4FF;
    
    .dorm-name {
      color: #4A90D9;
      font-weight: bold;
    }
  }
}

.dorm-name {
  font-size: 28rpx;
  color: #333;
}

.dorm-status {
  font-size: 22rpx;
  padding: 6rpx 16rpx;
  border-radius: 20rpx;
  
  &.available {
    background: #E6F7FF;
    color: #4A90D9;
  }
  
  &.full {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.maintenance {
    background: #FFF7E6;
    color: #FAAD14;
  }
}
</style>
