<template>
  <view class="detail-container">
    <view class="detail-header" v-if="maintenance">
      <view class="type-tag" :class="maintenance.type">
        {{ getTypeLabel(maintenance.type) }}
      </view>
      <view class="status-tag" :style="{ color: getStatusColor(maintenance.status) }">
        {{ getStatusLabel(maintenance.status) }}
      </view>
    </view>

    <view class="detail-body" v-if="maintenance">
      <text class="detail-title">{{ maintenance.title }}</text>
      <view class="detail-info">
        <view class="info-row">
          <text class="info-label">报修宿舍</text>
          <text class="info-value">{{ maintenance.dormitoryInfo }}</text>
        </view>
        <view class="info-row">
          <text class="info-label">报修人</text>
          <text class="info-value">{{ maintenance.studentName }}</text>
        </view>
        <view class="info-row">
          <text class="info-label">报修时间</text>
          <text class="info-value">{{ maintenance.createTime }}</text>
        </view>
        <view class="info-row">
          <text class="info-label">更新时间</text>
          <text class="info-value">{{ maintenance.updateTime }}</text>
        </view>
      </view>
      <view class="detail-content">
        <text class="content-title">问题描述</text>
        <text class="content-text">{{ maintenance.description }}</text>
      </view>
    </view>

    <view class="detail-footer" v-if="maintenance">
      <view class="footer-btn secondary" @click="goBack">
        <text>返回</text>
      </view>
      <view class="footer-btn primary" v-if="maintenance.status === 'pending'" @click="processMaintenance">
        <text>开始处理</text>
      </view>
      <view class="footer-btn primary" v-else-if="maintenance.status === 'processing'" @click="completeMaintenance">
        <text>完成维修</text>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { getMaintenanceById, maintenanceTypes, statusLabels, type Maintenance } from '@/data/maintenance'

const maintenance = ref<Maintenance | null>(null)

onLoad((options) => {
  const id = options?.id || 'm1'
  maintenance.value = getMaintenanceById(id) || null
})

function getTypeLabel(type: string) {
  const item = maintenanceTypes.find(t => t.value === type)
  return item?.label || type
}

function getStatusLabel(status: string) {
  return statusLabels[status]?.label || status
}

function getStatusColor(status: string) {
  return statusLabels[status]?.color || '#999'
}

function goBack() {
  uni.navigateBack()
}

function processMaintenance() {
  uni.showModal({
    title: '开始处理',
    content: '确定要开始处理此报修吗？',
    success: (res) => {
      if (res.confirm) {
        uni.showToast({ title: '已开始处理', icon: 'success' })
      }
    }
  })
}

function completeMaintenance() {
  uni.showModal({
    title: '完成维修',
    content: '确定维修已完成吗？',
    success: (res) => {
      if (res.confirm) {
        uni.showToast({ title: '维修完成', icon: 'success' })
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.detail-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.detail-header {
  background: #fff;
  padding: 24rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.type-tag {
  font-size: 24rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
  
  &.electric {
    background: #FFF1F0;
    color: #FF4D4F;
  }
  
  &.water {
    background: #E6F7FF;
    color: #1890FF;
  }
  
  &.furniture {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.other {
    background: #FFF7E6;
    color: #FAAD14;
  }
}

.status-tag {
  font-size: 28rpx;
  font-weight: bold;
}

.detail-body {
  margin: 20rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.detail-title {
  display: block;
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 20rpx;
}

.detail-info {
  border-bottom: 1rpx solid #f0f0f0;
  padding-bottom: 20rpx;
  margin-bottom: 20rpx;
}

.info-row {
  display: flex;
  justify-content: space-between;
  padding: 12rpx 0;
}

.info-label {
  font-size: 28rpx;
  color: #999;
}

.info-value {
  font-size: 28rpx;
  color: #333;
}

.detail-content {
  background: #fafafa;
  border-radius: 12rpx;
  padding: 20rpx;
}

.content-title {
  display: block;
  font-size: 28rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 12rpx;
}

.content-text {
  display: block;
  font-size: 28rpx;
  color: #666;
  line-height: 1.8;
}

.detail-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  padding: 20rpx;
  background: #fff;
  box-shadow: 0 -2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.footer-btn {
  flex: 1;
  padding: 24rpx;
  border-radius: 40rpx;
  text-align: center;
  font-size: 30rpx;
  
  &.primary {
    background: linear-gradient(135deg, #4A90D9, #6BA3E0);
    color: #fff;
    margin-left: 20rpx;
  }
  
  &.secondary {
    background: #f5f5f5;
    color: #666;
  }
  
  &:active {
    opacity: 0.8;
  }
}
</style>
