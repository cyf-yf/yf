<template>
  <view class="maintenance-container">
    <view class="tabs">
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'all' }"
        @click="activeTab = 'all'"
      >
        <text>全部</text>
        <text class="tab-count">{{ maintenanceList.length }}</text>
      </view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'pending' }"
        @click="activeTab = 'pending'"
      >
        <text>待处理</text>
        <text class="tab-count pending">{{ pendingCount }}</text>
      </view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'processing' }"
        @click="activeTab = 'processing'"
      >
        <text>处理中</text>
        <text class="tab-count processing">{{ processingCount }}</text>
      </view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'completed' }"
        @click="activeTab = 'completed'"
      >
        <text>已完成</text>
        <text class="tab-count completed">{{ completedCount }}</text>
      </view>
    </view>

    <view class="maintenance-list">
      <view class="maintenance-card" v-for="item in filteredList" :key="item.id">
        <view class="card-content" @click="goToDetail(item.id)">
          <view class="card-header">
            <view class="type-tag" :class="item.type">
              {{ getTypeLabel(item.type) }}
            </view>
            <view class="status-tag" :style="{ color: getStatusColor(item.status) }">
              {{ getStatusLabel(item.status) }}
            </view>
          </view>
          <text class="card-title">{{ item.title }}</text>
          <text class="card-desc">{{ item.description }}</text>
          <view class="card-footer">
            <view class="footer-info">
              <view class="info-item">
                <text class="info-icon">🏠</text>
                <text class="info-text">{{ item.dormitoryInfo }}</text>
              </view>
              <view class="info-item">
                <text class="info-icon">👤</text>
                <text class="info-text">{{ item.studentName }}</text>
              </view>
            </view>
            <text class="footer-time">{{ item.createTime }}</text>
          </view>
        </view>
        <view class="card-actions" v-if="item.status !== 'completed'">
          <view class="action-btn" :class="item.status === 'pending' ? 'process' : 'complete'" @click="handleStatus(item)">
            <text>{{ item.status === 'pending' ? '开始处理' : '完成维修' }}</text>
          </view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredList.length === 0">
      <text class="empty-icon">📝</text>
      <text class="empty-text">暂无报修记录</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { maintenanceList as initialList, maintenanceTypes, statusLabels, type Maintenance } from '@/data/maintenance'

const activeTab = ref('all')
const maintenanceList = ref<Maintenance[]>([...initialList])

const filteredList = computed(() => {
  if (activeTab.value === 'all') return maintenanceList.value
  return maintenanceList.value.filter(item => item.status === activeTab.value)
})

const pendingCount = computed(() => maintenanceList.value.filter(m => m.status === 'pending').length)
const processingCount = computed(() => maintenanceList.value.filter(m => m.status === 'processing').length)
const completedCount = computed(() => maintenanceList.value.filter(m => m.status === 'completed').length)

function getTypeLabel(type: string) {
  const item = maintenanceTypes.find(t => t.value === type)
  return item?.label || type
}

function getStatusLabel(status: string) {
  return statusLabels[status]?.label || status
}

function getStatusColor(status: string) {
  return statusLabels[status]?.color || '#999'
}

function goToDetail(id: string) {
  uni.navigateTo({ url: `/pages/maintenance/detail?id=${id}` })
}

function handleStatus(item: Maintenance) {
  const index = maintenanceList.value.findIndex(m => m.id === item.id)
  if (index === -1) return

  if (item.status === 'pending') {
    uni.showModal({
      title: '开始处理',
      content: `确定要开始处理「${item.title}」吗？`,
      success: (res) => {
        if (res.confirm) {
          maintenanceList.value[index].status = 'processing'
          activeTab.value = 'processing'
          uni.showToast({ title: '已开始处理', icon: 'success' })
        }
      }
    })
  } else if (item.status === 'processing') {
    uni.showModal({
      title: '完成维修',
      content: `确定维修已完成「${item.title}」吗？`,
      success: (res) => {
        if (res.confirm) {
          maintenanceList.value[index].status = 'completed'
          activeTab.value = 'completed'
          uni.showToast({ title: '维修完成', icon: 'success' })
        }
      }
    })
  }
}
</script>

<style lang="scss" scoped>
.maintenance-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.tabs {
  display: flex;
  background: #fff;
  padding: 20rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.tab-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 16rpx 0;
  border-radius: 12rpx;
  transition: all 0.3s;
  
  &.active {
    background: #E6F4FF;
    text {
      color: #4A90D9;
      font-weight: bold;
    }
  }
  
  text {
    font-size: 28rpx;
    color: #666;
  }
}

.tab-count {
  font-size: 22rpx;
  margin-top: 6rpx;
  padding: 4rpx 12rpx;
  border-radius: 20rpx;
  background: #f5f5f5;
  color: #999 !important;
  
  &.pending {
    background: #FFF7E6;
    color: #FAAD14 !important;
  }
  
  &.processing {
    background: #E6F4FF;
    color: #4A90D9 !important;
  }
  
  &.completed {
    background: #F6FFED;
    color: #52C41A !important;
  }
}

.maintenance-list {
  padding: 20rpx;
}

.maintenance-card {
  background: #fff;
  border-radius: 16rpx;
  margin-bottom: 20rpx;
  overflow: hidden;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.card-content {
  padding: 24rpx;
  
  &:active {
    background: #fafafa;
  }
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.type-tag {
  font-size: 22rpx;
  padding: 6rpx 16rpx;
  border-radius: 20rpx;
  
  &.electric {
    background: #FFF1F0;
    color: #FF4D4F;
  }
  
  &.water {
    background: #E6F7FF;
    color: #1890FF;
  }
  
  &.furniture {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &.other {
    background: #FFF7E6;
    color: #FAAD14;
  }
}

.status-tag {
  font-size: 26rpx;
  font-weight: bold;
}

.card-title {
  display: block;
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 12rpx;
}

.card-desc {
  display: block;
  font-size: 26rpx;
  color: #666;
  line-height: 1.6;
  margin-bottom: 16rpx;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 16rpx;
  border-top: 1rpx solid #f0f0f0;
}

.footer-info {
  display: flex;
}

.info-item {
  display: flex;
  align-items: center;
  margin-right: 32rpx;
}

.info-icon {
  font-size: 24rpx;
  margin-right: 8rpx;
}

.info-text {
  font-size: 24rpx;
  color: #999;
}

.footer-time {
  font-size: 24rpx;
  color: #999;
}

.card-actions {
  border-top: 1rpx solid #f0f0f0;
}

.action-btn {
  padding: 20rpx;
  text-align: center;
  font-size: 28rpx;
  
  &.process {
    background: #E6F7FF;
    color: #4A90D9;
  }
  
  &.complete {
    background: #F6FFED;
    color: #52C41A;
  }
  
  &:active {
    opacity: 0.7;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
