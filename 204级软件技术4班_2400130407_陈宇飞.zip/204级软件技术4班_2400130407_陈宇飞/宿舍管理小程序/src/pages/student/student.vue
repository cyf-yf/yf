<template>
  <view class="student-container">
    <view class="search-bar">
      <view class="search-input-wrap">
        <text class="search-icon">🔍</text>
        <input class="search-input" placeholder="搜索学号或姓名" v-model="searchText" />
      </view>
      <view class="add-btn" @click="goToAdd">
        <text>+ 添加</text>
      </view>
    </view>

    <view class="filter-section">
      <view class="filter-row">
        <view 
          class="filter-item" 
          :class="{ active: selectedBuilding === '' }"
          @click="selectedBuilding = ''"
        >全部</view>
        <view 
          class="filter-item" 
          v-for="building in buildings" 
          :key="building"
          :class="{ active: selectedBuilding === building }"
          @click="selectedBuilding = building"
        >{{ building }}</view>
      </view>
    </view>

    <view class="student-list">
      <view class="student-card" v-for="student in filteredStudents" :key="student.id" @click="goToDetail(student.id)">
        <view class="student-avatar">
          <text>{{ student.name.charAt(0) }}</text>
        </view>
        <view class="student-info">
          <view class="student-header">
            <text class="student-name">{{ student.name }}</text>
            <text class="student-id">{{ student.id }}</text>
          </view>
          <text class="student-detail">{{ student.grade }} · {{ student.major }}</text>
          <text class="student-dorm">{{ getDormName(student.id) }}</text>
        </view>
        <view class="student-actions">
          <view class="action-btn edit" @click.stop="editStudent(student)">
            <text>编辑</text>
          </view>
          <view class="action-btn delete" @click.stop="deleteStudent(student)">
            <text>删除</text>
          </view>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredStudents.length === 0">
      <text class="empty-icon">👤</text>
      <text class="empty-text">暂无学生信息</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useDormitoryStore } from '@/stores/dormitory'
import type { Student } from '@/data/dormitories'

const store = useDormitoryStore()

const searchText = ref('')
const selectedBuilding = ref('')

const allStudents = computed(() => store.getAllStudents())

const buildings = computed(() => {
  const set = new Set(store.dormitories.map(d => d.building))
  return Array.from(set)
})

const filteredStudents = computed(() => {
  return allStudents.value.filter(student => {
    const matchSearch = !searchText.value || 
      student.name.includes(searchText.value) || 
      student.id.includes(searchText.value)
    const matchBuilding = !selectedBuilding.value || student.dormName?.includes(selectedBuilding.value)
    return matchSearch && matchBuilding
  })
})

function getDormName(studentId: string) {
  const student = store.getStudentById(studentId)
  if (student && student.dormName) {
    const dorm = store.getDormById(student.dormId!)
    if (dorm) {
      const s = dorm.students.find(st => st.id === studentId)
      return `${student.dormName} ${s?.bedNumber || 0}号床`
    }
  }
  return ''
}

function goToAdd() {
  uni.navigateTo({ url: '/pages/student/add' })
}

function goToDetail(id: string) {
  uni.navigateTo({ url: `/pages/student/detail?id=${id}` })
}

function editStudent(student: Student & { dormId?: string; dormName?: string }) {
  uni.navigateTo({ url: `/pages/student/add?id=${student.id}` })
}

function deleteStudent(student: Student) {
  uni.showModal({
    title: '删除学生',
    content: `确定要删除学生「${student.name}」吗？`,
    success: (res) => {
      if (res.confirm) {
        const success = store.deleteStudent(student.id)
        if (success) {
          uni.showToast({ title: '删除成功', icon: 'success' })
        } else {
          uni.showToast({ title: '删除失败', icon: 'none' })
        }
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.student-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.search-bar {
  display: flex;
  padding: 20rpx;
  background: #fff;
}

.search-input-wrap {
  flex: 1;
  display: flex;
  align-items: center;
  background: #f5f5f5;
  border-radius: 40rpx;
  padding: 16rpx 24rpx;
}

.search-icon {
  font-size: 32rpx;
  margin-right: 12rpx;
}

.search-input {
  flex: 1;
  font-size: 28rpx;
}

.add-btn {
  margin-left: 20rpx;
  padding: 16rpx 24rpx;
  background: #4A90D9;
  color: #fff;
  border-radius: 40rpx;
  font-size: 28rpx;
}

.filter-section {
  background: #fff;
  padding: 16rpx 20rpx;
  border-top: 1rpx solid #f0f0f0;
}

.filter-row {
  display: flex;
  flex-wrap: wrap;
}

.filter-item {
  padding: 12rpx 24rpx;
  background: #f5f5f5;
  border-radius: 20rpx;
  font-size: 26rpx;
  margin-right: 16rpx;
  margin-bottom: 12rpx;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.student-list {
  padding: 20rpx;
}

.student-card {
  display: flex;
  align-items: center;
  background: #fff;
  border-radius: 16rpx;
  padding: 20rpx;
  margin-bottom: 16rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.student-avatar {
  width: 80rpx;
  height: 80rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 32rpx;
  font-weight: bold;
}

.student-info {
  flex: 1;
  margin-left: 20rpx;
}

.student-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.student-name {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.student-id {
  font-size: 24rpx;
  color: #999;
}

.student-detail {
  display: block;
  font-size: 24rpx;
  color: #666;
  margin-top: 8rpx;
}

.student-dorm {
  display: block;
  font-size: 24rpx;
  color: #4A90D9;
  margin-top: 8rpx;
}

.student-actions {
  display: flex;
  flex-direction: column;
}

.action-btn {
  padding: 12rpx 24rpx;
  border-radius: 20rpx;
  font-size: 24rpx;
  margin-bottom: 8rpx;
  text-align: center;
  
  &:last-child {
    margin-bottom: 0;
  }
  
  &.edit {
    background: #E6F7FF;
    color: #4A90D9;
  }
  
  &.delete {
    background: #FFF1F0;
    color: #FF4D4F;
  }
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
