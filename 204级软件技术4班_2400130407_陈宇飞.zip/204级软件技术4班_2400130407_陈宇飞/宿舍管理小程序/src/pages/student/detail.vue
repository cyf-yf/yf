<template>
  <view class="detail-container">
    <view class="detail-header" v-if="student">
      <view class="avatar">
        <text>{{ student.name.charAt(0) }}</text>
      </view>
      <view class="user-info">
        <text class="user-name">{{ student.name }}</text>
        <text class="user-id">{{ student.id }}</text>
      </view>
    </view>

    <view class="detail-body" v-if="student">
      <view class="info-card">
        <view class="info-title">
          <text class="title-icon">📋</text>
          <text class="title-text">基本信息</text>
        </view>
        <view class="info-item">
          <text class="info-label">学号</text>
          <text class="info-value">{{ student.id }}</text>
        </view>
        <view class="info-item">
          <text class="info-label">姓名</text>
          <text class="info-value">{{ student.name }}</text>
        </view>
        <view class="info-item">
          <text class="info-label">年级</text>
          <text class="info-value">{{ student.grade }}</text>
        </view>
        <view class="info-item">
          <text class="info-label">专业</text>
          <text class="info-value">{{ student.major }}</text>
        </view>
      </view>

      <view class="info-card">
        <view class="info-title">
          <text class="title-icon">🏠</text>
          <text class="title-text">住宿信息</text>
        </view>
        <view class="info-item">
          <text class="info-label">宿舍</text>
          <text class="info-value">{{ dormInfo }}</text>
        </view>
        <view class="info-item">
          <text class="info-label">床位</text>
          <text class="info-value">{{ student.bedNumber }}号床</text>
        </view>
      </view>

      <view class="info-card">
        <view class="info-title">
          <text class="title-icon">👥</text>
          <text class="title-text">室友</text>
        </view>
        <view class="roommates-list">
          <view class="roommate-item" v-for="mate in roommates" :key="mate.id">
            <view class="mate-avatar">
              <text>{{ mate.name.charAt(0) }}</text>
            </view>
            <view class="mate-info">
              <text class="mate-name">{{ mate.name }}</text>
              <text class="mate-bed">{{ mate.bedNumber }}号床</text>
            </view>
          </view>
        </view>
      </view>
    </view>

    <view class="detail-footer">
      <view class="footer-btn secondary" @click="editStudent">
        <text>编辑信息</text>
      </view>
      <view class="footer-btn primary" @click="deleteStudent">
        <text>删除学生</text>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { useDormitoryStore } from '@/stores/dormitory'
import type { Student } from '@/data/dormitories'

const store = useDormitoryStore()

const student = ref<Student | null>(null)
const dormInfo = ref('')

const roommates = computed(() => {
  if (!student.value) return []
  const studentData = store.getStudentById(student.value.id)
  if (studentData?.dormId) {
    const dorm = store.getDormById(studentData.dormId)
    if (dorm) {
      dormInfo.value = `${dorm.building} ${dorm.roomNumber}室`
      return dorm.students.filter(s => s.id !== student.value?.id)
    }
  }
  return []
})

onLoad((options) => {
  const id = options?.id || 's1'
  const found = store.getStudentById(id)
  if (found) {
    student.value = {
      id: found.id,
      name: found.name,
      avatar: '',
      grade: found.grade,
      major: found.major,
      bedNumber: found.bedNumber
    }
    if (found.dormId) {
      const dorm = store.getDormById(found.dormId)
      if (dorm) {
        dormInfo.value = `${dorm.building} ${dorm.roomNumber}室`
      }
    }
  }
})

function editStudent() {
  uni.navigateTo({ url: `/pages/student/add?id=${student.value?.id}` })
}

function deleteStudent() {
  uni.showModal({
    title: '删除学生',
    content: `确定要删除学生「${student.value?.name}」吗？`,
    success: (res) => {
      if (res.confirm) {
        const success = store.deleteStudent(student.value?.id || '')
        if (success) {
          uni.showToast({ title: '删除成功', icon: 'success' })
          setTimeout(() => {
            uni.navigateBack()
          }, 1500)
        } else {
          uni.showToast({ title: '删除失败', icon: 'none' })
        }
      }
    }
  })
}
</script>

<style lang="scss" scoped>
.detail-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.detail-header {
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  padding: 40rpx 30rpx;
  display: flex;
  align-items: center;
}

.avatar {
  width: 120rpx;
  height: 120rpx;
  background: rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 48rpx;
  font-weight: bold;
}

.user-info {
  flex: 1;
  margin-left: 24rpx;
}

.user-name {
  display: block;
  color: #fff;
  font-size: 36rpx;
  font-weight: bold;
}

.user-id {
  display: block;
  color: rgba(255, 255, 255, 0.8);
  font-size: 26rpx;
  margin-top: 8rpx;
}

.detail-body {
  padding: 20rpx;
}

.info-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.info-title {
  display: flex;
  align-items: center;
  margin-bottom: 20rpx;
  padding-bottom: 16rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.title-icon {
  font-size: 32rpx;
  margin-right: 12rpx;
}

.title-text {
  font-size: 30rpx;
  font-weight: bold;
  color: #333;
}

.info-item {
  display: flex;
  justify-content: space-between;
  padding: 16rpx 0;
}

.info-label {
  font-size: 28rpx;
  color: #999;
}

.info-value {
  font-size: 28rpx;
  color: #333;
}

.roommates-list {
  display: flex;
  flex-direction: column;
}

.roommate-item {
  display: flex;
  align-items: center;
  padding: 16rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  
  &:last-child {
    border-bottom: none;
  }
}

.mate-avatar {
  width: 64rpx;
  height: 64rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  font-size: 28rpx;
  font-weight: bold;
}

.mate-info {
  flex: 1;
  margin-left: 16rpx;
}

.mate-name {
  display: block;
  font-size: 28rpx;
  color: #333;
}

.mate-bed {
  display: block;
  font-size: 24rpx;
  color: #999;
  margin-top: 4rpx;
}

.detail-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  padding: 20rpx;
  background: #fff;
  box-shadow: 0 -2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.footer-btn {
  flex: 1;
  padding: 24rpx;
  border-radius: 40rpx;
  text-align: center;
  font-size: 30rpx;
  
  &.primary {
    background: #FF4D4F;
    color: #fff;
    margin-left: 20rpx;
  }
  
  &.secondary {
    background: #f5f5f5;
    color: #666;
    border: 2rpx solid #ddd;
  }
  
  &:active {
    opacity: 0.8;
  }
}
</style>
