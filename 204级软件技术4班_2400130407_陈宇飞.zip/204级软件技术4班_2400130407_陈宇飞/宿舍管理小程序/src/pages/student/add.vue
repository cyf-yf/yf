<template>
  <view class="add-container">
    <view class="form-card">
      <view class="form-item">
        <text class="form-label">学号 *</text>
        <input class="form-input" placeholder="请输入学号" v-model="formData.id" />
      </view>

      <view class="form-item">
        <text class="form-label">姓名 *</text>
        <input class="form-input" placeholder="请输入姓名" v-model="formData.name" />
      </view>

      <view class="form-item">
        <text class="form-label">年级 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="grade in grades" 
            :key="grade"
            :class="{ active: formData.grade === grade }"
            @click="formData.grade = grade"
          >{{ grade }}</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">专业 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="major in majors" 
            :key="major"
            :class="{ active: formData.major === major }"
            @click="formData.major = major"
          >{{ major }}</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">分配宿舍 *</text>
        <view class="dorm-select" @click="showDormPicker = true">
          <text class="select-text">{{ formData.dormName || '请选择宿舍' }}</text>
          <text class="select-arrow">›</text>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">床位号 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            v-for="bed in bedNumbers" 
            :key="bed"
            :class="{ active: formData.bedNumber === bed }"
            @click="formData.bedNumber = bed"
          >{{ bed }}号床</view>
        </view>
      </view>
    </view>

    <view class="submit-btn" @click="submitForm">
      <text>{{ isEdit ? '保存修改' : '添加学生' }}</text>
    </view>

    <view class="dorm-picker" v-show="showDormPicker" @click="showDormPicker = false">
      <view class="picker-content" @click.stop>
        <view class="picker-header">
          <text class="picker-title">选择宿舍</text>
          <text class="picker-close" @click="showDormPicker = false">✕</text>
        </view>
        <scroll-view class="picker-list" scroll-y>
          <view 
            class="picker-item" 
            v-for="dorm in availableDorms" 
            :key="dorm.id"
            :class="{ active: formData.dormId === dorm.id }"
            @click="selectDorm(dorm)"
          >
            <text class="dorm-name">{{ dorm.building }} {{ dorm.roomNumber }}室</text>
            <view class="dorm-available">剩余{{ dorm.capacity - dorm.currentCount }}床位</view>
          </view>
        </scroll-view>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive, ref, computed } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { useDormitoryStore } from '@/stores/dormitory'

const store = useDormitoryStore()

const showDormPicker = ref(false)
const isEdit = ref(false)

const grades = ['2021级', '2022级', '2023级', '2024级']
const majors = ['计算机科学', '软件工程', '人工智能', '网络工程', '信息安全', '数据科学']
const bedNumbers = [1, 2, 3, 4, 5, 6]

const formData = reactive({
  id: '',
  name: '',
  grade: '',
  major: '',
  dormId: '',
  dormName: '',
  bedNumber: 1
})

const availableDorms = computed(() => store.getAvailableDorms())

onLoad((options) => {
  if (options?.id) {
    isEdit.value = true
    const student = store.getStudentById(options.id)
    if (student) {
      formData.id = student.id
      formData.name = student.name
      formData.grade = student.grade
      formData.major = student.major
      formData.dormId = student.dormId || ''
      formData.dormName = student.dormName || ''
      formData.bedNumber = student.bedNumber
    }
  }
})

function selectDorm(dorm: typeof store.dormitories[0]) {
  formData.dormId = dorm.id
  formData.dormName = `${dorm.building} ${dorm.roomNumber}室`
  showDormPicker.value = false
}

function submitForm() {
  if (!formData.id) {
    uni.showToast({ title: '请输入学号', icon: 'none' })
    return
  }
  if (!formData.name) {
    uni.showToast({ title: '请输入姓名', icon: 'none' })
    return
  }
  if (!formData.grade) {
    uni.showToast({ title: '请选择年级', icon: 'none' })
    return
  }
  if (!formData.major) {
    uni.showToast({ title: '请选择专业', icon: 'none' })
    return
  }
  if (!formData.dormId) {
    uni.showToast({ title: '请选择宿舍', icon: 'none' })
    return
  }
  
  uni.showLoading({ title: '提交中...' })
  
  setTimeout(() => {
    uni.hideLoading()
    let success = false
    if (isEdit.value) {
      success = store.updateStudent({
        id: formData.id,
        name: formData.name,
        grade: formData.grade,
        major: formData.major,
        bedNumber: formData.bedNumber,
        dormId: formData.dormId
      })
    } else {
      const existingStudent = store.getStudentById(formData.id)
      if (existingStudent) {
        uni.showToast({ title: '学号已存在', icon: 'none' })
        return
      }
      success = store.addStudent({
        id: formData.id,
        name: formData.name,
        grade: formData.grade,
        major: formData.major,
        bedNumber: formData.bedNumber,
        dormId: formData.dormId
      })
    }
    
    if (success) {
      uni.showToast({ title: isEdit.value ? '修改成功' : '添加成功', icon: 'success' })
      setTimeout(() => {
        uni.navigateBack()
      }, 1500)
    } else {
      uni.showToast({ title: '操作失败', icon: 'none' })
    }
  }, 500)
}
</script>

<style lang="scss" scoped>
.add-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.form-card {
  background: #fff;
  margin: 20rpx;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.form-item {
  margin-bottom: 24rpx;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.form-label {
  font-size: 28rpx;
  color: #333;
  margin-bottom: 12rpx;
  display: block;
}

.form-input {
  width: 100%;
  padding: 24rpx 20rpx;
  background: #fff;
  border: 2rpx solid #e8e8e8;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
  cursor: text;
  pointer-events: auto;
  position: relative;
  z-index: 1;
  
  &:focus {
    border-color: #4A90D9;
    outline: none;
    box-shadow: 0 0 0 4rpx rgba(74, 144, 217, 0.1);
  }
  
  &::placeholder {
    color: #ccc;
  }
}

.type-options {
  display: flex;
  flex-wrap: wrap;
}

.type-option {
  padding: 16rpx 24rpx;
  background: #f5f5f5;
  border-radius: 20rpx;
  font-size: 26rpx;
  color: #666;
  margin-right: 16rpx;
  margin-bottom: 12rpx;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.dorm-select {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
}

.select-text {
  font-size: 28rpx;
  color: #666;
}

.select-arrow {
  font-size: 36rpx;
  color: #999;
}

.submit-btn {
  margin: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}

.dorm-picker {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  z-index: 1000;
}

.picker-content {
  width: 100%;
  background: #fff;
  border-radius: 24rpx 24rpx 0 0;
  max-height: 70vh;
}

.picker-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.picker-title {
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
}

.picker-close {
  font-size: 36rpx;
  color: #999;
}

.picker-list {
  max-height: 60vh;
}

.picker-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24rpx 30rpx;
  border-bottom: 1rpx solid #f0f0f0;
  
  &.active {
    background: #E6F4FF;
    
    .dorm-name {
      color: #4A90D9;
      font-weight: bold;
    }
  }
}

.dorm-name {
  font-size: 28rpx;
  color: #333;
}

.dorm-available {
  font-size: 24rpx;
  color: #52C41A;
}
</style>
