<template>
  <view class="notice-container">
    <view class="tabs">
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'all' }"
        @click="activeTab = 'all'"
      >全部</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'important' }"
        @click="activeTab = 'important'"
      >重要</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'warning' }"
        @click="activeTab = 'warning'"
      >警告</view>
      <view 
        class="tab-item" 
        :class="{ active: activeTab === 'normal' }"
        @click="activeTab = 'normal'"
      >普通</view>
    </view>

    <view class="notice-list">
      <view class="notice-card" v-for="notice in filteredNotices" :key="notice.id" @click="goToDetail(notice.id)">
        <view class="notice-header">
          <view class="type-badge" :style="{ background: getTypeBg(notice.type), color: getTypeColor(notice.type) }">
            {{ getTypeLabel(notice.type) }}
          </view>
          <text class="notice-time">{{ notice.createTime }}</text>
        </view>
        <text class="notice-title">{{ notice.title }}</text>
        <text class="notice-content">{{ notice.content }}</text>
        <view class="notice-footer">
          <text class="notice-author">发布者：{{ notice.author }}</text>
          <text class="notice-more">查看详情 ›</text>
        </view>
      </view>
    </view>

    <view class="empty-state" v-if="filteredNotices.length === 0">
      <text class="empty-icon">📢</text>
      <text class="empty-text">暂无通知</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { notices, typeLabels } from '@/data/notices'

const activeTab = ref('all')

const filteredNotices = computed(() => {
  if (activeTab.value === 'all') return notices
  return notices.filter(n => n.type === activeTab.value)
})

function getTypeLabel(type: string) {
  return typeLabels[type]?.label || '普通'
}

function getTypeBg(type: string) {
  return typeLabels[type]?.bgColor || '#E6F4FF'
}

function getTypeColor(type: string) {
  return typeLabels[type]?.color || '#4A90D9'
}

function goToDetail(id: string) {
  uni.navigateTo({ url: `/pages/notice/detail?id=${id}` })
}
</script>

<style lang="scss" scoped>
.notice-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 120rpx;
}

.tabs {
  display: flex;
  background: #fff;
  padding: 20rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.tab-item {
  flex: 1;
  text-align: center;
  padding: 16rpx 0;
  font-size: 28rpx;
  color: #666;
  border-radius: 12rpx;
  transition: all 0.3s;
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.notice-list {
  padding: 20rpx;
}

.notice-card {
  background: #fff;
  border-radius: 16rpx;
  padding: 24rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.notice-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.type-badge {
  font-size: 22rpx;
  padding: 6rpx 16rpx;
  border-radius: 20rpx;
}

.notice-time {
  font-size: 24rpx;
  color: #999;
}

.notice-title {
  display: block;
  font-size: 32rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 12rpx;
}

.notice-content {
  display: block;
  font-size: 26rpx;
  color: #666;
  line-height: 1.6;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.notice-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 16rpx;
  padding-top: 16rpx;
  border-top: 1rpx solid #f0f0f0;
}

.notice-author {
  font-size: 24rpx;
  color: #999;
}

.notice-more {
  font-size: 24rpx;
  color: #4A90D9;
}

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 100rpx 0;
}

.empty-icon {
  font-size: 80rpx;
  margin-bottom: 20rpx;
}

.empty-text {
  font-size: 28rpx;
  color: #999;
}
</style>
