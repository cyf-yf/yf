<template>
  <view class="detail-container">
    <view class="detail-header" v-if="notice">
      <view class="type-badge" :style="{ background: getTypeBg(notice.type), color: getTypeColor(notice.type) }">
        {{ getTypeLabel(notice.type) }}
      </view>
      <text class="notice-time">{{ notice.createTime }}</text>
    </view>

    <view class="detail-body" v-if="notice">
      <text class="notice-title">{{ notice.title }}</text>
      <view class="notice-info">
        <text class="info-item">发布者：{{ notice.author }}</text>
      </view>
      <text class="notice-content">{{ notice.content }}</text>
    </view>

    <view class="detail-footer">
      <view class="footer-btn" @click="goBack">
        <text>返回列表</text>
      </view>
    </view>
  </view>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { getNoticeById, type Notice, typeLabels } from '@/data/notices'

const notice = ref<Notice | null>(null)

onLoad((options) => {
  const id = options?.id || 'n1'
  notice.value = getNoticeById(id) || null
})

function getTypeLabel(type: string) {
  return typeLabels[type]?.label || '普通'
}

function getTypeBg(type: string) {
  return typeLabels[type]?.bgColor || '#E6F4FF'
}

function getTypeColor(type: string) {
  return typeLabels[type]?.color || '#4A90D9'
}

function goBack() {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
.detail-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.detail-header {
  background: #fff;
  padding: 30rpx;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.type-badge {
  font-size: 24rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
}

.notice-time {
  font-size: 26rpx;
  color: #999;
}

.detail-body {
  margin: 20rpx;
  background: #fff;
  border-radius: 16rpx;
  padding: 30rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.notice-title {
  display: block;
  font-size: 36rpx;
  font-weight: bold;
  color: #333;
  margin-bottom: 20rpx;
}

.notice-info {
  margin-bottom: 20rpx;
  padding-bottom: 20rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.info-item {
  font-size: 26rpx;
  color: #999;
}

.notice-content {
  display: block;
  font-size: 28rpx;
  color: #666;
  line-height: 1.8;
  white-space: pre-wrap;
}

.detail-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 20rpx;
  background: #fff;
  box-shadow: 0 -2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.footer-btn {
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
