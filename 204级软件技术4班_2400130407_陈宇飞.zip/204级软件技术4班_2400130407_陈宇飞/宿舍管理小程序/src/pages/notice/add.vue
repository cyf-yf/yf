<template>
  <view class="add-container">
    <view class="form-card">
      <view class="form-item">
        <text class="form-label">通知类型 *</text>
        <view class="type-options">
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'important' }"
            @click="formData.type = 'important'"
          >重要</view>
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'warning' }"
            @click="formData.type = 'warning'"
          >警告</view>
          <view 
            class="type-option" 
            :class="{ active: formData.type === 'normal' }"
            @click="formData.type = 'normal'"
          >普通</view>
        </view>
      </view>

      <view class="form-item">
        <text class="form-label">通知标题 *</text>
        <input 
          class="form-input" 
          placeholder="请输入通知标题" 
          v-model="formData.title"
        />
      </view>

      <view class="form-item">
        <text class="form-label">通知内容 *</text>
        <textarea 
          class="form-textarea" 
          placeholder="请输入通知内容..." 
          v-model="formData.content"
        ></textarea>
      </view>

      <view class="form-item">
        <text class="form-label">发布人</text>
        <input class="form-input" placeholder="请输入发布人" v-model="formData.author" />
      </view>
    </view>

    <view class="submit-btn" @click="submitForm">
      <text>发布通知</text>
    </view>
  </view>
</template>

<script setup lang="ts">
import { reactive } from 'vue'

const formData = reactive({
  type: 'normal' as 'important' | 'warning' | 'normal',
  title: '',
  content: '',
  author: '宿舍管理中心'
})

function submitForm() {
  if (!formData.title) {
    uni.showToast({ title: '请输入通知标题', icon: 'none' })
    return
  }
  if (!formData.content) {
    uni.showToast({ title: '请输入通知内容', icon: 'none' })
    return
  }
  
  uni.showLoading({ title: '发布中...' })
  
  setTimeout(() => {
    uni.hideLoading()
    uni.showToast({ title: '发布成功', icon: 'success' })
    setTimeout(() => {
      uni.navigateBack()
    }, 1500)
  }, 1000)
}
</script>

<style lang="scss" scoped>
.add-container {
  min-height: 100vh;
  background: #f5f5f5;
  padding-bottom: 140rpx;
}

.form-card {
  background: #fff;
  margin: 20rpx;
  border-radius: 16rpx;
  padding: 24rpx;
  box-shadow: 0 2rpx 12rpx rgba(0, 0, 0, 0.05);
}

.form-item {
  margin-bottom: 24rpx;
  
  &:last-child {
    margin-bottom: 0;
  }
}

.form-label {
  font-size: 28rpx;
  color: #333;
  margin-bottom: 12rpx;
  display: block;
}

.type-options {
  display: flex;
}

.type-option {
  flex: 1;
  padding: 20rpx;
  background: #f5f5f5;
  border-radius: 12rpx;
  font-size: 28rpx;
  color: #666;
  text-align: center;
  margin-right: 12rpx;
  
  &:last-child {
    margin-right: 0;
  }
  
  &.active {
    background: #4A90D9;
    color: #fff;
  }
}

.form-input {
  width: 100%;
  padding: 28rpx 24rpx;
  background: #ffffff !important;
  border: 2rpx solid #d0d0d0 !important;
  border-radius: 16rpx;
  font-size: 30rpx;
  box-sizing: border-box;
  cursor: text !important;
  pointer-events: auto !important;
  position: relative;
  z-index: 100;
  min-height: 88rpx;
  line-height: 1.6;
  color: #333333;
  font-weight: 500;
  
  &:focus {
    border-color: #4A90D9 !important;
    outline: none;
    box-shadow: 0 0 0 4rpx rgba(74, 144, 217, 0.2);
    background: #f8fafc !important;
  }
  
  &::placeholder {
    color: #cccccc;
    font-weight: 400;
  }
}

.form-textarea {
  width: 100%;
  height: 300rpx;
  padding: 24rpx 20rpx;
  background: #fff;
  border: 2rpx solid #e8e8e8;
  border-radius: 12rpx;
  font-size: 28rpx;
  box-sizing: border-box;
  
  &:focus {
    border-color: #4A90D9;
    outline: none;
    box-shadow: 0 0 0 4rpx rgba(74, 144, 217, 0.1);
  }
}

.submit-btn {
  margin: 20rpx;
  padding: 28rpx;
  background: linear-gradient(135deg, #4A90D9, #6BA3E0);
  color: #fff;
  border-radius: 40rpx;
  text-align: center;
  font-size: 32rpx;
  font-weight: bold;
  
  &:active {
    opacity: 0.8;
  }
}
</style>
