import { defineStore } from 'pinia'
import { ref } from 'vue'
import { dormitories as initialDorms, type Dormitory, type Student } from '@/data/dormitories'

export const useDormitoryStore = defineStore('dormitory', () => {
  const dormitories = ref<Dormitory[]>(JSON.parse(JSON.stringify(initialDorms)))

  function getAllStudents(): (Student & { dormId: string; dormName: string })[] {
    const students: (Student & { dormId: string; dormName: string })[] = []
    dormitories.value.forEach(dorm => {
      dorm.students.forEach(student => {
        students.push({
          ...student,
          dormId: dorm.id,
          dormName: `${dorm.building} ${dorm.roomNumber}室`
        })
      })
    })
    return students
  }

  function getStudentById(id: string): (Student & { dormId?: string; dormName?: string }) | null {
    for (const dorm of dormitories.value) {
      const student = dorm.students.find(s => s.id === id)
      if (student) {
        return {
          ...student,
          dormId: dorm.id,
          dormName: `${dorm.building} ${dorm.roomNumber}室`
        }
      }
    }
    return null
  }

  function addStudent(student: Omit<Student, 'avatar'> & { dormId: string }) {
    const dorm = dormitories.value.find(d => d.id === student.dormId)
    if (dorm) {
      const newStudent: Student = {
        id: student.id,
        name: student.name,
        avatar: '',
        grade: student.grade,
        major: student.major,
        bedNumber: student.bedNumber
      }
      dorm.students.push(newStudent)
      dorm.currentCount = dorm.students.length
      if (dorm.currentCount >= dorm.capacity) {
        dorm.status = 'full'
      } else {
        dorm.status = 'available'
      }
      return true
    }
    return false
  }

  function updateStudent(student: Omit<Student, 'avatar'> & { dormId: string }) {
    for (const dorm of dormitories.value) {
      const index = dorm.students.findIndex(s => s.id === student.id)
      if (index !== -1) {
        dorm.students[index] = {
          id: student.id,
          name: student.name,
          avatar: '',
          grade: student.grade,
          major: student.major,
          bedNumber: student.bedNumber
        }
        return true
      }
    }
    return false
  }

  function deleteStudent(studentId: string) {
    for (const dorm of dormitories.value) {
      const index = dorm.students.findIndex(s => s.id === studentId)
      if (index !== -1) {
        dorm.students.splice(index, 1)
        dorm.currentCount = dorm.students.length
        if (dorm.currentCount === 0) {
          dorm.status = 'available'
        } else if (dorm.currentCount < dorm.capacity) {
          dorm.status = 'available'
        }
        return true
      }
    }
    return false
  }

  function getAvailableDorms(): Dormitory[] {
    return dormitories.value.filter(d => d.status === 'available' || d.currentCount < d.capacity)
  }

  function getDormById(id: string): Dormitory | undefined {
    return dormitories.value.find(d => d.id === id)
  }

  function addDorm(dorm: Omit<Dormitory, 'id' | 'students' | 'currentCount'>) {
    const newDorm: Dormitory = {
      id: Date.now().toString(),
      building: dorm.building,
      roomNumber: dorm.roomNumber,
      floor: dorm.floor,
      type: dorm.type,
      capacity: dorm.capacity,
      currentCount: 0,
      status: dorm.status,
      students: []
    }
    dormitories.value.push(newDorm)
    return newDorm
  }

  function updateDorm(id: string, updates: Partial<Omit<Dormitory, 'id' | 'students' | 'currentCount'>>) {
    const index = dormitories.value.findIndex(d => d.id === id)
    if (index !== -1) {
      dormitories.value[index] = { ...dormitories.value[index], ...updates }
      return true
    }
    return false
  }

  function deleteDorm(id: string) {
    const index = dormitories.value.findIndex(d => d.id === id)
    if (index !== -1) {
      dormitories.value.splice(index, 1)
      return true
    }
    return false
  }

  return {
    dormitories,
    getAllStudents,
    getStudentById,
    addStudent,
    updateStudent,
    deleteStudent,
    getAvailableDorms,
    getDormById,
    addDorm,
    updateDorm,
    deleteDorm
  }
})
