export interface Notice {
  id: string
  title: string
  content: string
  type: 'important' | 'normal' | 'warning'
  createTime: string
  author: string
}

export const notices: Notice[] = [
  {
    id: 'n1',
    title: '关于宿舍安全检查的通知',
    content: '为确保同学们的居住安全，学校将于下周一（1月22日）上午9:00-11:00对所有宿舍进行安全检查，请同学们提前整理好宿舍卫生，配合检查工作。检查内容包括：1. 违规电器使用情况；2. 消防通道是否畅通；3. 电线线路安全；4. 卫生状况。请大家积极配合，谢谢！',
    type: 'important',
    createTime: '2024-01-15 08:00',
    author: '宿舍管理中心'
  },
  {
    id: 'n2',
    title: '寒假离校注意事项',
    content: '寒假即将来临，请同学们在离校前做好以下准备：1. 关闭宿舍所有电器电源；2. 关好门窗；3. 妥善保管个人贵重物品；4. 将不需要带走的物品整理好；5. 到宿管处登记离校信息。祝同学们寒假愉快！',
    type: 'normal',
    createTime: '2024-01-14 10:30',
    author: '学生处'
  },
  {
    id: 'n3',
    title: '宿舍维修服务时间调整通知',
    content: '因维修人员轮休，1月18日至1月20日期间，维修服务时间调整为上午9:00-12:00，下午14:00-17:00，请同学们合理安排报修时间，给您带来不便敬请谅解。',
    type: 'warning',
    createTime: '2024-01-13 16:00',
    author: '后勤保障处'
  },
  {
    id: 'n4',
    title: '新学期宿舍分配结果查询',
    content: '2024年春季学期宿舍分配结果已公布，请同学们登录宿舍管理系统查询自己的宿舍分配情况。如有异议，请于1月20日前联系宿舍管理中心。',
    type: 'normal',
    createTime: '2024-01-12 09:00',
    author: '宿舍管理中心'
  },
  {
    id: 'n5',
    title: '关于禁止使用违规电器的通知',
    content: '近期发现部分宿舍存在使用违规电器的情况，为保障消防安全，现再次强调：禁止使用电热毯、电暖器、电磁炉、电饭煲等大功率电器。一经发现，将没收电器并通报批评。请同学们遵守规定，共同维护宿舍安全。',
    type: 'warning',
    createTime: '2024-01-10 14:00',
    author: '保卫处'
  }
]

export const typeLabels: Record<string, { label: string; color: string; bgColor: string }> = {
  important: { label: '重要', color: '#FFFFFF', bgColor: '#FF4D4F' },
  normal: { label: '普通', color: '#4A90D9', bgColor: '#E6F4FF' },
  warning: { label: '警告', color: '#FAAD14', bgColor: '#FFF7E6' }
}

export function getNoticeById(id: string): Notice | undefined {
  return notices.find(n => n.id === id)
}
