export interface Maintenance {
  id: string
  title: string
  description: string
  dormitoryId: string
  dormitoryInfo: string
  type: 'electric' | 'water' | 'furniture' | 'other'
  status: 'pending' | 'processing' | 'completed'
  createTime: string
  updateTime: string
  studentName: string
}

export const maintenanceList: Maintenance[] = [
  {
    id: 'm1',
    title: '灯泡损坏',
    description: '宿舍101房间的天花板灯不亮了，需要更换灯泡',
    dormitoryId: '1',
    dormitoryInfo: '1号楼 101室',
    type: 'electric',
    status: 'pending',
    createTime: '2024-01-15 10:30',
    updateTime: '2024-01-15 10:30',
    studentName: '张三'
  },
  {
    id: 'm2',
    title: '水龙头漏水',
    description: '宿舍201房间卫生间水龙头一直滴水，影响正常使用',
    dormitoryId: '3',
    dormitoryInfo: '2号楼 201室',
    type: 'water',
    status: 'processing',
    createTime: '2024-01-14 14:20',
    updateTime: '2024-01-14 16:00',
    studentName: '吴十'
  },
  {
    id: 'm3',
    title: '书桌损坏',
    description: '宿舍102房间的书桌抽屉无法正常打开，可能是滑轨坏了',
    dormitoryId: '2',
    dormitoryInfo: '1号楼 102室',
    type: 'furniture',
    status: 'completed',
    createTime: '2024-01-10 09:15',
    updateTime: '2024-01-12 11:30',
    studentName: '赵六'
  },
  {
    id: 'm4',
    title: '空调故障',
    description: '宿舍301房间空调无法制冷，夏天太热了',
    dormitoryId: '5',
    dormitoryInfo: '3号楼 301室',
    type: 'electric',
    status: 'pending',
    createTime: '2024-01-15 16:45',
    updateTime: '2024-01-15 16:45',
    studentName: '陈明'
  },
  {
    id: 'm5',
    title: '门锁损坏',
    description: '宿舍202房间门锁不好用，钥匙很难插进去',
    dormitoryId: '4',
    dormitoryInfo: '2号楼 202室',
    type: 'other',
    status: 'processing',
    createTime: '2024-01-13 11:00',
    updateTime: '2024-01-14 09:00',
    studentName: '王小红'
  }
]

export const maintenanceTypes = [
  { value: 'electric', label: '电器维修' },
  { value: 'water', label: '水管维修' },
  { value: 'furniture', label: '家具维修' },
  { value: 'other', label: '其他维修' }
]

export const statusLabels: Record<string, { label: string; color: string }> = {
  pending: { label: '待处理', color: '#FAAD14' },
  processing: { label: '处理中', color: '#4A90D9' },
  completed: { label: '已完成', color: '#52C41A' }
}

export function getMaintenanceById(id: string): Maintenance | undefined {
  return maintenanceList.find(m => m.id === id)
}

export function getMaintenanceByStatus(status: string): Maintenance[] {
  return maintenanceList.filter(m => m.status === status)
}
