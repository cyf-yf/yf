export interface Dormitory {
  id: string
  building: string
  roomNumber: string
  floor: number
  capacity: number
  currentCount: number
  type: 'male' | 'female' | 'mixed'
  status: 'available' | 'full' | 'maintenance'
  students: Student[]
}

export interface Student {
  id: string
  name: string
  avatar: string
  grade: string
  major: string
  bedNumber: number
}

export const dormitories: Dormitory[] = [
  {
    id: '1',
    building: '1号楼',
    roomNumber: '101',
    floor: 1,
    capacity: 4,
    currentCount: 3,
    type: 'male',
    status: 'available',
    students: [
      { id: 's1', name: '张三', avatar: '', grade: '2022级', major: '计算机科学', bedNumber: 1 },
      { id: 's2', name: '李四', avatar: '', grade: '2022级', major: '软件工程', bedNumber: 2 },
      { id: 's3', name: '王五', avatar: '', grade: '2022级', major: '人工智能', bedNumber: 3 }
    ]
  },
  {
    id: '2',
    building: '1号楼',
    roomNumber: '102',
    floor: 1,
    capacity: 4,
    currentCount: 4,
    type: 'male',
    status: 'full',
    students: [
      { id: 's4', name: '赵六', avatar: '', grade: '2022级', major: '网络工程', bedNumber: 1 },
      { id: 's5', name: '钱七', avatar: '', grade: '2022级', major: '信息安全', bedNumber: 2 },
      { id: 's6', name: '孙八', avatar: '', grade: '2022级', major: '数据科学', bedNumber: 3 },
      { id: 's7', name: '周九', avatar: '', grade: '2022级', major: '物联网', bedNumber: 4 }
    ]
  },
  {
    id: '3',
    building: '2号楼',
    roomNumber: '201',
    floor: 2,
    capacity: 4,
    currentCount: 2,
    type: 'female',
    status: 'available',
    students: [
      { id: 's8', name: '吴十', avatar: '', grade: '2022级', major: '计算机科学', bedNumber: 1 },
      { id: 's9', name: '郑十一', avatar: '', grade: '2022级', major: '软件工程', bedNumber: 2 }
    ]
  },
  {
    id: '4',
    building: '2号楼',
    roomNumber: '202',
    floor: 2,
    capacity: 4,
    currentCount: 4,
    type: 'female',
    status: 'full',
    students: [
      { id: 's10', name: '王小红', avatar: '', grade: '2022级', major: '人工智能', bedNumber: 1 },
      { id: 's11', name: '李小花', avatar: '', grade: '2022级', major: '网络工程', bedNumber: 2 },
      { id: 's12', name: '张小美', avatar: '', grade: '2022级', major: '信息安全', bedNumber: 3 },
      { id: 's13', name: '刘小丽', avatar: '', grade: '2022级', major: '数据科学', bedNumber: 4 }
    ]
  },
  {
    id: '5',
    building: '3号楼',
    roomNumber: '301',
    floor: 3,
    capacity: 6,
    currentCount: 5,
    type: 'mixed',
    status: 'available',
    students: [
      { id: 's14', name: '陈明', avatar: '', grade: '2023级', major: '计算机科学', bedNumber: 1 },
      { id: 's15', name: '林芳', avatar: '', grade: '2023级', major: '软件工程', bedNumber: 2 },
      { id: 's16', name: '刘洋', avatar: '', grade: '2023级', major: '人工智能', bedNumber: 3 },
      { id: 's17', name: '杨帆', avatar: '', grade: '2023级', major: '网络工程', bedNumber: 4 },
      { id: 's18', name: '周晓', avatar: '', grade: '2023级', major: '信息安全', bedNumber: 5 }
    ]
  }
]

export function getDormitoryById(id: string): Dormitory | undefined {
  return dormitories.find(d => d.id === id)
}

export function getDormitoriesByBuilding(building: string): Dormitory[] {
  return dormitories.filter(d => d.building === building)
}

export function getAvailableDormitories(): Dormitory[] {
  return dormitories.filter(d => d.status === 'available')
}
